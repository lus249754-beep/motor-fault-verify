"""Two-stage at 60 Hz / 0.07 N.m: 7 known classes + rejection and interval naming for 12.30 %."""
import json

import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = np.array([1.98, 3.97, 5.95, 8.33, 20.64, 28.97, 45.63])
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]
GAP = (3, 4)          # 8.33 % .. 20.64 %
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 32, 11, 2, 5), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 9, 2, 4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 7, 2, 3), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.feat = nn.Linear(128, 96)
        self.proj = nn.Sequential(nn.Linear(96, 64), nn.ReLU(), nn.Linear(64, 32))
        self.fc = nn.Linear(96, n_cls)
        self.reg = nn.Linear(96, 1)

    def forward(self, x):
        f = self.feat(self.body(x).flatten(1))
        return f, self.proj(f), self.fc(f), self.reg(f).squeeze(1)


def supcon(z, y, t=0.1):
    z = F.normalize(z, 1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    X = np.asarray(sio.loadmat("a1_slices/60-0.07-1-A-12.30-slices.mat")["X"], dtype=np.float32)
    m3, s3 = mu.reshape(3, 1), sd.reshape(3, 1)
    xu = np.stack([((resample(X[:, :, k], 1500, axis=0).T - m3) / s3).astype(np.float32)
                   for k in range(X.shape[2])])
    print("known", tr.sum(), va.sum(), te.sum(), "unseen", len(xu), flush=True)

    Xt, Yt = torch.from_numpy(x), torch.from_numpy(y)
    tgt = torch.from_numpy(np.log(SEV)[y].astype(np.float32))
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    epochs = 150
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(Xt[s], int(torch.randint(-100, 101, (1,))), dims=2)
            f, z, out, r = net(xb)
            loss = (F.cross_entropy(out, Yt[s], label_smoothing=0.03)
                    + 0.5 * supcon(z, Yt[s]) + 0.5 * F.smooth_l1_loss(r, tgt[s]))
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == Yt[s]).sum().item(); tot += len(s)
        sched.step(); net.eval()
        with torch.no_grad():
            vacc = float((net(Xt[va])[2].argmax(1).numpy() == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()

    def run(a):
        with torch.no_grad():
            f, z, logit, r = net(torch.from_numpy(a))
        return f.numpy(), logit.numpy(), np.exp(r.numpy())

    ftr, _, rtr = run(x[tr])
    fva, _, rva = run(x[va])
    fte, lte, rte = run(x[te])
    fuk, luk, ruk = run(xu)

    proto = np.stack([ftr[y[tr] == c].mean(0) for c in range(7)])
    icov = np.linalg.inv(np.cov((ftr - proto[y[tr]]).T) + 1e-3 * np.eye(ftr.shape[1]))

    def mahal(f):
        return np.stack([np.einsum("ij,jk,ik->i", f - proto[c], icov, f - proto[c])
                         for c in range(7)]).min(0)

    thr = float(np.quantile(mahal(fva), 0.99))
    ka = float((mahal(fte) < thr).mean())
    ur = float((mahal(fuk) >= thr).mean())
    with torch.no_grad():
        acc = float((net(torch.from_numpy(x[te]))[2].argmax(1).numpy() == y[te]).mean())
    mae = float(np.mean(np.abs(rte - SEV[y[te]])))
    in_band = float(((ruk > SEV[GAP[0]]) & (ruk < SEV[GAP[1]])).mean())
    print(f"known acc {acc:.3f} | MAE {mae:.2f} | known accept {ka:.3f} | unseen reject {ur:.3f} "
          f"| stage2 in-band {in_band:.3f} | median {np.median(ruk):.2f}", flush=True)

    json.dump({"known_acc": acc, "severity_mae_percent": mae,
               "known_accept": ka, "unknown_reject": ur,
               "stage2_in_band": in_band, "stage2_median": float(np.median(ruk)),
               "threshold": thr, "n_unseen": int(len(ruk))},
              open("a1_2stage_60hz_007.json", "w"), indent=1)

    # figure: t-SNE (known test + unseen) and predicted severity histogram
    E = np.concatenate([fte, fuk])
    E = E / (np.linalg.norm(E, axis=1, keepdims=True) + 1e-9)
    Ys = tsne(E, perplexity=12, iters=1200)
    nk = len(fte)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5.4), gridspec_kw={"width_ratios": [1.25, 1]})
    for c in range(7):
        mm = y[te] == c
        a1.scatter(Ys[:nk][mm, 0], Ys[:nk][mm, 1], s=60, c=COLORS[c], alpha=0.95,
                   edgecolors="white", linewidths=0.6, label=f"{SEV_TXT[c]} %（第{LABELS[c]}档）")
    a1.scatter(Ys[nk:, 0], Ys[nk:, 1], s=28, marker="x", c="#B22222", linewidths=1.0,
               alpha=0.85, label="12.30 %（未参与训练）")
    a1.set_xticks([]); a1.set_yticks([])
    a1.legend(fontsize=8.5, loc="best", framealpha=0.9, title="严重度")
    a1.set_title(f"t-SNE（60 Hz / 0.07 N·m；测试切片 {nk}，未见 {len(fuk)}）", fontsize=10.5)
    a2.hist(ruk, bins=np.linspace(6, 24, 30), color="#C44E52", alpha=0.85)
    a2.axvspan(SEV[3], SEV[4], color="#4C72B0", alpha=0.15)
    a2.axvline(SEV[3], color="#4C72B0", ls="--"); a2.axvline(SEV[4], color="#4C72B0", ls="--")
    a2.set_xlabel("第二级回归预测的严重度（%）"); a2.set_ylabel("切片数")
    a2.set_title(f"未见 12.30 %：{in_band*100:.1f}% 落在 8.33–20.64 % → 第 5 档", fontsize=10.5)
    fig.suptitle("单一工况 60 Hz / 0.07 N·m 两级诊断", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig("figs/a1_2stage_60hz_007.png", dpi=190)
    torch.save(net.state_dict(), "a1_2stage_60hz_007.pt")
    print("saved")


if __name__ == "__main__":
    main()
