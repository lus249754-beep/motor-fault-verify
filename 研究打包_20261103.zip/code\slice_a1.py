"""Slice the A1 motor records into overlapping windows.

One MAT per source record:
    X          (windowLength, 3, nWin) float32   three-phase currents CH02/04/06
    Y          (nWin, 1) uint8                   severity label 1..9
    sourceStart/sourceEnd (nWin,) int64          sample indices in the source record
    split      (nWin, 1) object                  train / val / test (chronological)

Default protocol: window = 150 000 points (0.15 s at 1 MHz), stride = 50 000.
"""
import argparse
import csv
import os
import re
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mat5 import Mat5

CH = ("CH02", "CH04", "CH06")
NAME_RE = re.compile(
    r"^(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)-(A|Health)-(\d+(?:\.\d+)?)-FOC\.MAT$", re.I)
LEVELS = [1.98, 3.97, 5.95, 8.33, 12.30, 20.64, 28.97, 37.30, 45.63]


def load_currents(path):
    m = Mat5(path)
    out = {}
    pos = 128
    while pos < m.size - 8:
        t = m.tag(pos)
        if t is None or not (1 <= t[0] <= 30):
            break
        typ, size, dpos, end = t
        if typ == 14:
            name, val = m.matrix(pos)
            if name in CH and val is not None:
                out[name] = np.asarray(val, dtype=np.float32).ravel()
        pos = m._advance(pos, dpos, size)
    m.close()
    missing = [c for c in CH if c not in out]
    if missing:
        raise RuntimeError(f"{os.path.basename(path)}: missing {missing}")
    n = {len(out[c]) for c in CH}
    if len(n) != 1:
        raise RuntimeError(f"{os.path.basename(path)}: channel lengths differ {n}")
    return np.column_stack([out[c] for c in CH])


def label_of(severity):
    for i, v in enumerate(LEVELS, start=1):
        if abs(v - severity) < 0.005:
            return i
    raise ValueError(f"unknown severity {severity}")


def split_of(start, total, window, train_frac=0.6, val_frac=0.2):
    cut1 = int(total * train_frac)
    cut2 = int(total * (train_frac + val_frac))
    if start + window <= cut1:
        return "train"
    if start >= cut1 + window and start + window <= cut2:
        return "val"
    if start >= cut2 + window:
        return "test"
    return "gap"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=r"E:\A1")
    ap.add_argument("--out", required=True)
    ap.add_argument("--window", type=int, default=150_000)
    ap.add_argument("--stride", type=int, default=50_000)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    import scipy.io as sio

    os.makedirs(args.out, exist_ok=True)
    files = sorted(f for f in os.listdir(args.root) if f.upper().endswith(".MAT"))
    if args.limit:
        files = files[:args.limit]
    rows, total_win, t0 = [], 0, time.time()
    for i, fn in enumerate(files, 1):
        m = NAME_RE.match(fn)
        if not m:
            print("skip (name):", fn, flush=True)
            continue
        speed, load, rf, state, sev = m.groups()
        speed, load, rf, sev = float(speed), float(load), float(rf), float(sev)
        path = os.path.join(args.root, fn)
        x = load_currents(path)
        n = x.shape[0]
        starts = np.arange(0, n - args.window + 1, args.stride, dtype=np.int64)
        splits = np.array([split_of(int(s), n, args.window) for s in starts])
        keep = splits != "gap"
        starts, splits, idx = starts[keep], splits[keep], np.flatnonzero(keep)
        X = np.empty((args.window, 3, idx.size), dtype=np.float32)
        for k, s in enumerate(starts):
            X[:, :, k] = x[s:s + args.window]
        y = np.full((idx.size, 1), label_of(sev), dtype=np.uint8)
        out = os.path.join(args.out, fn.replace("-FOC.MAT", "-slices.mat"))
        sio.savemat(out, {
            "X": X,
            "Y": y,
            "sourceStart": starts.astype(np.int64),
            "sourceEnd": (starts + args.window).astype(np.int64),
            "split": splits.astype(object),
            "fs": np.int32(1_000_000),
            "windowLength": np.int32(args.window),
            "step": np.int32(args.stride),
            "channelNames": np.array(CH, dtype=object),
            "sourceFile": np.array(fn, dtype=object),
            "speed": np.float64(speed),
            "load": np.float64(load),
            "resistance": np.float64(rf),
            "severity": np.float64(sev),
            "label": np.uint8(label_of(sev)),
            "samplingRateVerified": np.uint8(0),
            "samplingRateSource": np.array("assumed_1MHz_no_WaveInfo", dtype=object),
        }, do_compression=True, oned_as="column")
        total_win += idx.size
        size_mb = os.path.getsize(out) / 1e6
        for s, e, sp in zip(starts, starts + args.window, splits):
            rows.append(dict(record=fn, label=label_of(sev), severity=sev, speed=speed,
                             load=load, resistance=rf, split=sp,
                             source_start=int(s), source_end=int(e),
                             file=os.path.basename(out)))
        print(f"[{i:3d}/{len(files)}] {fn:38s} n={idx.size:3d} {size_mb:7.1f} MB "
              f"| total {total_win:6d} | {time.time()-t0:6.0f}s", flush=True)

    with open(os.path.join(args.out, "slice_index.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"done: {len(files)} records, {total_win} slices, {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
