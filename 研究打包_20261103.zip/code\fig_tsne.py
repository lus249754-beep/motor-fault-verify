"""t-SNE + confusion-matrix figure for the 7-class CNN."""
import json
import os

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]

d = np.load("a1_7cls_tsne.npz", allow_pickle=True)
Y, y, cm = d["Y"], d["y"], d["cm"]
m = json.load(open("a1_7cls_metrics.json"))
acc = m["test_acc"]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.6, 5.8), gridspec_kw={"width_ratios": [1.45, 1]})

for c in range(7):
    k = y == c
    ax1.scatter(Y[k, 0], Y[k, 1], s=13, c=COLORS[c], alpha=0.75, linewidths=0,
                label=f"{SEV[c]} %")
ax1.set_title(f"t-SNE 特征分布（测试集，n={len(y)}）", fontsize=12)
ax1.set_xticks([]); ax1.set_yticks([])
ax1.legend(title="严重程度", fontsize=9, title_fontsize=9, markerscale=1.6,
           loc="best", frameon=True, ncol=1)
for s in ax1.spines.values():
    s.set_color("#cccccc")

cmn = cm / cm.sum(1, keepdims=True)
im = ax2.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
for i in range(7):
    for j in range(7):
        v = cm[i, j]
        if v:
            ax2.text(j, i, f"{v}", ha="center", va="center", fontsize=8,
                     color="white" if cmn[i, j] > 0.5 else "#222222")
ax2.set_xticks(range(7)); ax2.set_yticks(range(7))
ax2.set_xticklabels(SEV, rotation=45, ha="right", fontsize=8)
ax2.set_yticklabels(SEV, fontsize=8)
ax2.set_xlabel("预测类别（%）", fontsize=10)
ax2.set_ylabel("真实类别（%）", fontsize=10)
ax2.set_title(f"混淆矩阵（测试准确率 {acc*100:.2f}%）", fontsize=12)
cb = fig.colorbar(im, ax=ax2, fraction=0.046, pad=0.03)
cb.set_label("行归一化比例", fontsize=8)

fig.suptitle("基于三相电流的一维卷积神经网络 —— 7 类匝间短路严重程度识别", fontsize=14, y=0.99)
fig.tight_layout(rect=(0, 0, 1, 0.95))
os.makedirs("figs", exist_ok=True)
out = "figs/a1_cnn_tsne.png"
fig.savefig(out, dpi=200)
print("saved", out, "acc", acc)
