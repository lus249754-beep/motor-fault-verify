"""Is severity separable after per-condition normalisation? Record-level probe."""
import numpy as np
import torch

d = np.load("a1_7cls_10k.npz", allow_pickle=True)
x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
LABELS = [1, 2, 3, 4, 6, 7, 9]
y = np.array([LABELS.index(int(v)) for v in y0])

N = x.shape[2]
FS = 10000.0
w = np.hanning(N).astype(np.float32)
spec = np.fft.rfft(x * w, axis=2)


def feats(i):
    k1 = max(1, int(round(speed[i] / (FS / N))))
    ph = spec[i, :, k1]
    a1 = np.abs(ph)
    m = a1.mean() + 1e-9
    seq2 = np.abs(ph[0] + ph[1] * np.exp(2j * np.pi / 3) + ph[2] * np.exp(-2j * np.pi / 3)) / (3 * m)
    seq0 = np.abs(ph.sum()) / (3 * m)
    f = [seq2, seq0] + list(a1 / m)
    for h in (2, 3, 5, 7):
        f += list(np.abs(spec[i, :, h * k1]) / (a1 + 1e-9))
    for c in range(3):
        band = np.abs(spec[i, c, k1 + 1:])
        f.append(float(np.sqrt((band ** 2).sum()) / (a1[c] + 1e-9)))
    return np.array(f, dtype=np.float32)


F = np.stack([feats(i) for i in range(len(y))])
print("feature matrix", F.shape)

# per-record mean feature (a recording summarised by its average window)
records, groups = [], {}
for i in range(len(y)):
    groups.setdefault(rec[i], []).append(i)
names = sorted(groups)
R = np.stack([F[groups[n]].mean(0) for n in names])
Rrec = np.array(names)
Ry = np.array([y[groups[n][0]] for n in names])
Rs = np.array([speed[groups[n][0]] for n in names])
Rl = np.array([load[groups[n][0]] for n in names])

print("\nmean |seq2| by class x condition (rows=condition, cols=severity):")
conds = sorted({(s, l) for s, l in zip(Rs, Rl)})
for s, l in conds:
    m = (Rs == s) & (Rl == l)
    vals = [R[m & (Ry == c), 0].mean() for c in range(7)]
    print(f"  {s:4.0f}Hz {l:5.2f}Nm : " + " ".join(f"{v:.3f}" for v in vals))

# condition-normalised features: subtract the condition mean over TRAIN records only
rng = np.random.RandomState(0)
te = np.zeros(len(names), bool)
for c in range(7):
    idx = np.flatnonzero(Ry == c)
    rng.shuffle(idx)
    te[idx[:2]] = True
tr = ~te

Z = R.copy()
for s, l in conds:
    m = (Rs == s) & (Rl == l)
    mu = R[m & tr].mean(0)
    sd = R[m & tr].std(0) + 1e-6
    Z[m] = (R[m] - mu) / sd

net = torch.nn.Sequential(torch.nn.Linear(Z.shape[1], 32), torch.nn.ReLU(), torch.nn.Linear(32, 7))
opt = torch.optim.Adam(net.parameters(), lr=1e-2, weight_decay=1e-2)
Xt, yt = torch.from_numpy(Z.astype(np.float32)), torch.from_numpy(Ry)
for _ in range(500):
    opt.zero_grad()
    torch.nn.functional.cross_entropy(net(Xt[tr]), yt[tr]).backward()
    opt.step()
with torch.no_grad():
    p = net(Xt).argmax(1).numpy()
print(f"\nrecord-level, condition-normalised features: train {(p[tr]==Ry[tr]).mean():.3f} "
      f"test {(p[te]==Ry[te]).mean():.3f}  (test records {te.sum()})")

# same without normalisation
net2 = torch.nn.Sequential(torch.nn.Linear(R.shape[1], 32), torch.nn.ReLU(), torch.nn.Linear(32, 7))
opt2 = torch.optim.Adam(net2.parameters(), lr=1e-2, weight_decay=1e-2)
Rt = torch.from_numpy(R.astype(np.float32))
for _ in range(500):
    opt2.zero_grad()
    torch.nn.functional.cross_entropy(net2(Rt[tr]), yt[tr]).backward()
    opt2.step()
with torch.no_grad():
    p2 = net2(Rt).argmax(1).numpy()
print(f"record-level, raw features            : train {(p2[tr]==Ry[tr]).mean():.3f} "
      f"test {(p2[te]==Ry[te]).mean():.3f}")
