"""Stage-2 t-SNE with per-load offset removed (condition-normalised feature space)."""
import glob
import os

import numpy as np
import scipy.io as sio
import torch
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from stage2_60hz import CNN, LABELS, SEV
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0)
    x, rec, load = x[m], rec[m], load[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    keep = np.zeros(len(y), bool)
    for r in set(rec):
        idx = np.flatnonzero(rec == r)
        keep[idx[::3]] = True
    x, y, load = x[keep], y[keep], load[keep]

    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        n = len(idx)
        te[idx[:int(0.15 * n)]] = True
        tr[idx[int(0.30 * n):]] = True

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    files = [f for f in sorted(glob.glob("a1_slices/*-slices.mat"))
             if os.path.basename(f).startswith("60-") and "-A-12.30-slices" in f]
    xs, xl = [], []
    m3, s3 = mu.reshape(3, 1), sd.reshape(3, 1)
    for f in files:
        X = np.asarray(sio.loadmat(f)["X"], dtype=np.float32)[:, :, ::3]
        for k in range(X.shape[2]):
            yy = resample(X[:, :, k], 1500, axis=0).T
            xs.append(((yy - m3) / s3).astype(np.float32))
        xl.append(np.full(X.shape[2], float(os.path.basename(f).split("-")[1])))
    xu, lu = np.stack(xs), np.concatenate(xl)

    net = CNN()
    net.load_state_dict(torch.load("a1_stage2_model.pt", map_location="cpu"))
    net.eval()

    def embed(a):
        with torch.no_grad():
            f, _, _, r = net(torch.from_numpy(a))
        return f.numpy(), np.exp(r.numpy())

    ftr, _ = embed(x[tr])
    fte, rte = embed(x[te])
    fuk, ruk = embed(xu)

    # remove the per-load offset, estimated on the training recordings
    off = {round(float(l), 2): (ftr[np.isclose(load[tr], l)].mean(0),
                                ftr[np.isclose(load[tr], l)].std(0) + 1e-6)
           for l in np.unique(load[tr])}
    fte_n = np.stack([(fte[i] - off[round(float(l), 2)][0]) / off[round(float(l), 2)][1]
                      for i, l in enumerate(load[te])])
    fuk_n = np.stack([(fuk[i] - off[round(float(l), 2)][0]) / off[round(float(l), 2)][1]
                      for i, l in enumerate(lu)])

    E = np.concatenate([fte_n, fuk_n])
    E = E / (np.linalg.norm(E, axis=1, keepdims=True) + 1e-9)
    Y = tsne(E, perplexity=15, iters=1500)
    nk = len(fte)

    fig, ax = plt.subplots(figsize=(9.6, 7.2))
    for c in range(7):
        mm = y[te] == c
        ax.scatter(Y[:nk][mm, 0], Y[:nk][mm, 1], s=70, c=COLORS[c], alpha=0.95,
                   edgecolors="white", linewidths=0.6,
                   label=f"{SEV_TXT[c]} %（第{LABELS[c]}档）")
    ax.scatter(Y[nk:, 0], Y[nk:, 1], s=28, marker="x", c="#B22222", linewidths=1.0,
               alpha=0.75, label="12.30 %（未参与训练）")
    ax.set_xticks([]); ax.set_yticks([])
    ax.legend(fontsize=9, loc="best", framealpha=0.9, title="严重度")
    ax.set_title("60 Hz 两级模型 t-SNE（已扣除负载偏移）\n"
                 f"未见 12.30 % 预测中位数 {np.median(ruk):.2f} % → 第 5 档", fontsize=11)
    for s in ax.spines.values():
        s.set_color("#cccccc")
    fig.tight_layout()
    fig.savefig("figs/a1_stage2_tsne_cond.png", dpi=200)
    print("saved")


if __name__ == "__main__":
    main()
