"""Re-run t-SNE on the saved CNN features and redraw the figure."""
import json

import numpy as np

from tsne_torch import tsne

d = dict(np.load("a1_7cls_tsne.npz", allow_pickle=True))
feat = d["feat"]
print("features", feat.shape)
Y = tsne(feat, perplexity=30, iters=1000)
d["Y"] = Y
np.savez("a1_7cls_tsne.npz", **d)
print("saved")
