"""Minimal MAT v5 reader (pure Python + numpy), big/little endian aware.

Supports: numeric matrices (all classes), char, cell, struct, and
miCOMPRESSED payloads. Written because scipy is unavailable in this runtime.

    from mat5 import loadmat
    d = loadmat(path)
"""
import io
import os
import zlib

import numpy as np

MX = {1: "cell", 2: "struct", 3: "object", 4: "char", 5: "sparse", 6: "double",
      7: "single", 8: "int8", 9: "uint8", 10: "int16", 11: "uint16",
      12: "int32", 13: "uint32", 14: "int64", 15: "uint64"}

NP_OF_MX = {"double": "f8", "single": "f4", "int8": "i1", "uint8": "u1",
            "int16": "i2", "uint16": "u2", "int32": "i4", "uint32": "u4",
            "int64": "i8", "uint64": "u8"}

NUMERIC_OR_CHAR = set(range(1, 19)) | {15}


class Mat5:
    def __init__(self, src):
        if isinstance(src, (bytes, bytearray)):
            self.f = io.BytesIO(src)
            hdr = self.f.read(128)
            self.f.seek(0)
            self.size = len(src)
        else:
            self.f = open(src, "rb")
            hdr = self.f.read(128)
            self.size = os.path.getsize(src)
        self.header = hdr
        ind = hdr[126:128]
        self.endian = "big" if ind == b"MI" else "little"

    def close(self):
        try:
            self.f.close()
        except Exception:
            pass

    # ------------------------------------------------------------------
    def tag(self, pos):
        self.f.seek(pos)
        b = self.f.read(8)
        if len(b) < 8:
            return None
        val = int.from_bytes(b[:4], self.endian)
        if 1 <= val <= 30:                      # normal data element
            size = int.from_bytes(b[4:8], self.endian)
            data_pos = pos + 8
            end = data_pos + size + ((8 - size % 8) % 8)
            return (val, size, data_pos, end)
        if self.endian == "big":                # small data element
            typ, size = val >> 16, val & 0xFFFF
        else:
            typ, size = val & 0xFFFF, val >> 16
        return (typ, size, pos + 4, pos + 8)

    def read_at(self, size, pos):
        self.f.seek(pos)
        return self.f.read(size)

    def elem(self, pos):
        t = self.tag(pos)
        if t is None:
            return None
        typ, size, dpos, end = t
        return typ, self.read_at(size, dpos), end

    # ------------------------------------------------------------------
    def matrix(self, pos):
        t = self.tag(pos)                       # outer miMATRIX tag
        if t is None:
            return None, None
        p = t[2]
        # ---- array flags (miUINT32, 8 bytes: flags + nzmax)
        t = self.tag(p)
        flags_raw = self.read_at(t[1], t[2])
        p = t[3]
        word = int.from_bytes(flags_raw[0:4], self.endian)
        cls = word & 0xFF
        class_name = MX.get(cls, "unknown")
        # ---- dimensions (miINT32)
        t = self.tag(p)
        dims = np.frombuffer(self.read_at(t[1], t[2]), dtype=np.dtype("i4").newbyteorder(">" if self.endian == "big" else "<"))
        dims = [int(x) for x in dims]
        p = t[3]
        # ---- name (miINT8). Two on-disk conventions exist:
        #   standard small element : [u16 type][u16 size][4-byte inline data]
        #   DL850 export           : [u16 size][u16 type][4-byte inline data]
        t = self.tag(p)
        b8 = self.read_at(8, p)
        val = int.from_bytes(b8[0:4], self.endian)
        name = None
        if 1 <= val <= 30:
            name = self.read_at(t[1], t[2]).decode("latin1")
            p = t[3]
        else:
            def cand(type_bytes, size_bytes):
                ty = int.from_bytes(type_bytes, self.endian)
                sz = int.from_bytes(size_bytes, self.endian)
                if 1 <= ty <= 18 and 0 <= sz <= 4:
                    data = b8[4:4 + sz]
                    pad = b8[4 + sz:8]
                    return data, all(ch == 0 for ch in pad)
                return None
            c_std = cand(b8[0:2], b8[2:4])
            c_dl = cand(b8[2:4], b8[0:2])
            chosen = None
            if c_std and c_std[1]:
                chosen = c_std
            elif c_dl and c_dl[1]:
                chosen = c_dl
            elif c_std:
                chosen = c_std
            elif c_dl:
                chosen = c_dl
            if chosen is None:
                name = self.read_at(t[1], t[2]).decode("latin1")
                p = t[3]
            else:
                name = chosen[0].decode("latin1", "replace")
                p = p + 8
        n = int(np.prod(dims)) if dims else 0

        if class_name in NP_OF_MX:
            t = self.tag(p)
            typ, size, dpos, end = t
            buf = self.read_at(size, dpos)
            dt = np.dtype(NP_OF_MX[class_name]).newbyteorder(">" if self.endian == "big" else "<")
            if typ == 15:
                buf = self._unpack_compressed(buf, n, dt)
            arr = np.frombuffer(buf, dtype=dt)
            if dims:
                arr = arr[:n].reshape(tuple(dims), order="F")
            return name, arr

        if class_name == "char":
            t = self.tag(p)
            typ, size, dpos, end = t
            buf = self.read_at(size, dpos)
            if typ == 15:
                buf = zlib.decompress(buf)
            if typ == 4:
                s = buf.decode("utf-16-be" if self.endian == "big" else "utf-16-le", "replace")
            elif typ in (16, 2):
                s = buf.decode("utf-8", "replace")
            else:
                s = buf.decode("latin1", "replace")
            return name, s

        if class_name == "cell":
            out = []
            for _ in range(n):
                _, val = self.matrix(p)
                t = self.tag(p)
                p = t[3]
                out.append(val)
            return name, out

        if class_name == "struct":
            return name, self._struct(p, dims)

        return name, None

    def _unpack_compressed(self, buf, n, dt):
        d = zlib.decompress(buf)
        if len(d) >= 8:
            val = int.from_bytes(d[0:4], self.endian)
            if 1 <= val <= 30:
                size = int.from_bytes(d[4:8], self.endian)
                payload = d[8:8 + size]
                if len(payload) == n * dt.itemsize:
                    return payload
        return d

    def _struct(self, p, dims):
        t = self.tag(p)                          # field name length
        fnl = int.from_bytes(self.read_at(t[1], t[2])[:4], self.endian)
        p = t[3]
        t = self.tag(p)                          # field names
        names = self.read_at(t[1], t[2]).decode("latin1")
        p = t[3]
        fnames = [names[i:i + fnl].split("\x00")[0] for i in range(0, len(names), fnl)]
        n = int(np.prod(dims)) if dims else 1
        recs = []
        for _ in range(n):
            rec = {}
            for fn in fnames:
                t = self.tag(p)
                if t is None:
                    break
                _, val = self.matrix(p)
                p = t[3]
                rec[fn] = val
            recs.append(rec)
        return recs[0] if n == 1 else recs

    # ------------------------------------------------------------------
    def _advance(self, pos, dpos, size):
        """Some writers omit the 8-byte padding; validate before accepting."""
        for cand in (dpos + size, pos + 8 + size):
            if cand >= self.size - 4:
                return cand
            t = self.tag(cand)
            if t is not None and 1 <= t[0] <= 18:
                return cand
        return dpos + size

    def load(self):
        out = {}
        pos = 128
        while pos < self.size - 8:
            t = self.tag(pos)
            if t is None or not (1 <= t[0] <= 30):
                break
            typ, size, dpos, end = t
            if typ == 15:                       # whole variable compressed
                buf = zlib.decompress(self.read_at(size, dpos))
                sub = Mat5(buf)
                out.update(_load_from(sub))
                sub.close()
                pos = self._advance(pos, dpos, size)
                continue
            if typ == 14:
                name, val = self.matrix(pos)
                if name:
                    out[name] = val
                pos = self._advance(pos, dpos, size)
                continue
            pos = self._advance(pos, dpos, size)
        return out


def _load_from(mat):
    """parse a Mat5 instance whose buffer starts with a matrix element"""
    out = {}
    pos = 0
    while pos < mat.size - 8:
        t = mat.tag(pos)
        if t is None or not (1 <= t[0] <= 30):
            break
        typ, size, dpos, end = t
        if typ == 14:
            name, val = mat.matrix(pos)
            if name:
                out[name] = val
            pos = mat._advance(pos, dpos, size)
            continue
        if typ == 15:
            buf = zlib.decompress(mat.read_at(size, dpos))
            sub = Mat5(buf)
            out.update(_load_from(sub))
            sub.close()
            pos = mat._advance(pos, dpos, size)
            continue
        pos = mat._advance(pos, dpos, size)
    return out


def loadmat(path):
    r = Mat5(path)
    try:
        return r.load()
    finally:
        r.close()


if __name__ == "__main__":
    import sys
    import time
    t0 = time.time()
    d = loadmat(sys.argv[1])
    print("loaded %.2fs, %d vars" % (time.time() - t0, len(d)))
    for k, v in d.items():
        if isinstance(v, np.ndarray):
            extra = ""
            if v.size:
                try:
                    extra = f" min={float(np.nanmin(v)):.4g} max={float(np.nanmax(v)):.4g}"
                except Exception:
                    pass
            print(f"{k:22s} {str(v.shape):16s} {str(v.dtype):8s}{extra}")
        elif isinstance(v, str):
            print(f"{k:22s} str[{len(v)}]: {v[:80]!r}")
        elif isinstance(v, dict):
            print(f"{k:22s} struct {list(v.keys())}")
        elif isinstance(v, list):
            print(f"{k:22s} cell len={len(v)}")
        else:
            print(f"{k:22s} {type(v)}")
