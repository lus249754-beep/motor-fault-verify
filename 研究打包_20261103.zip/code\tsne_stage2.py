"""t-SNE of the two-stage 60 Hz model: 7 known classes + the unseen 12.30 % level (no class 8)."""
import glob
import os

import numpy as np
import scipy.io as sio
import torch
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from stage2_60hz import CNN, LABELS, SEV
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed = d["X"], d["y"], d["record"], d["speed"]
    m = np.isclose(speed, 60.0)
    x, rec = x[m], rec[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    keep = np.zeros(len(y), bool)
    for r in set(rec):
        idx = np.flatnonzero(rec == r)
        keep[idx[::3]] = True
    x, y = x[keep], y[keep]

    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        n = len(idx)
        te[idx[:int(0.15 * n)]] = True
        va[idx[int(0.15 * n):int(0.30 * n)]] = True
        tr[idx[int(0.30 * n):]] = True

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    files = [f for f in sorted(glob.glob("a1_slices/*-slices.mat"))
             if os.path.basename(f).startswith("60-") and "-A-12.30-slices" in f]
    xs = []
    m3, s3 = mu.reshape(3, 1), sd.reshape(3, 1)
    for f in files:
        X = np.asarray(sio.loadmat(f)["X"], dtype=np.float32)[:, :, ::3]
        for k in range(X.shape[2]):
            yy = resample(X[:, :, k], 1500, axis=0).T
            xs.append(((yy - m3) / s3).astype(np.float32))
    xu = np.stack(xs)

    net = CNN()
    net.load_state_dict(torch.load("a1_stage2_model.pt", map_location="cpu"))
    net.eval()

    def embed(a):
        with torch.no_grad():
            f, _, _, r = net(torch.from_numpy(a))
        return f.numpy(), np.exp(r.numpy())

    fte, rte = embed(x[te])
    fuk, ruk = embed(xu)

    E = np.concatenate([fte, fuk])
    Y = tsne(E, perplexity=28, iters=1500)
    nk = len(fte)

    fig, ax = plt.subplots(figsize=(9.6, 7.2))
    for c in range(7):
        m = y[te] == c
        ax.scatter(Y[:nk][m, 0], Y[:nk][m, 1], s=72, c=COLORS[c], alpha=0.95,
                   edgecolors="white", linewidths=0.6,
                   label=f"{SEV_TXT[c]} %（第{LABELS[c]}档）")
    ax.scatter(Y[nk:, 0], Y[nk:, 1], s=30, marker="x", c="#B22222", linewidths=1.1, alpha=0.75,
               label="12.30 %（未参与训练）")
    ax.set_xticks([]); ax.set_yticks([])
    ax.legend(fontsize=9, loc="best", framealpha=0.9, title="严重度")
    ax.set_title("60 Hz 两级模型 t-SNE：7 个已知档 + 未见的 12.30 %\n"
                 f"未见样本回归预测中位数 {np.median(ruk):.2f} %，全部落在 8.33 %–20.64 % 之间 → 第 5 档",
                 fontsize=11)
    for s in ax.spines.values():
        s.set_color("#cccccc")
    fig.tight_layout()
    fig.savefig("figs/a1_stage2_tsne.png", dpi=200)
    print("saved", "pred median", np.median(ruk))


if __name__ == "__main__":
    main()
