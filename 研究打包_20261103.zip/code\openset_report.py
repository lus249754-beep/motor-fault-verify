"""Recompute open-set metrics with the correct threshold direction, and draw the figure."""
import json

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]

d = np.load("a1_openset_60hz.npz", allow_pickle=True)
fte, fuk = d["fte"], d["fuk"]
yte, yu = d["yte"], d["yu"]
ste, suk = d["ste"].item(), d["suk"].item()
sva = d["sva"].item()


def auroc(s_known, s_unknown):
    s = np.concatenate([s_known, s_unknown])
    lab = np.concatenate([np.ones(len(s_known)), np.zeros(len(s_unknown))])
    o = np.argsort(-s)
    lab = lab[o]
    tpr = np.cumsum(lab) / lab.sum()
    fpr = np.cumsum(1 - lab) / (1 - lab).sum()
    return float(np.trapezoid(tpr, fpr))


res = {}
for name in ("msp", "mahalanobis"):
    thr = float(np.quantile(sva[name], 0.01))          # 99 % of known validation kept
    ka = float((ste[name] >= thr).mean())
    ur = float((suk[name] < thr).mean())
    res[name] = dict(threshold=thr, known_accept=ka, unknown_reject=ur,
                     auroc=auroc(ste[name], suk[name]),
                     reject_by_class={int(k): float((suk[name][yu == k] < thr).mean())
                                      for k in (5, 8)})
    print(name, json.dumps(res[name], indent=1))

json.dump(res, open("a1_openset_60hz.json", "w"), indent=1)

# ---- figure
fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.4, 5.6), gridspec_kw={"width_ratios": [1, 1.15]})
dist_known = -ste["mahalanobis"]
dist_5 = -suk["mahalanobis"][yu == 5]
dist_8 = -suk["mahalanobis"][yu == 8]
thr = -res["mahalanobis"]["threshold"]
bins = np.linspace(0, max(dist_known.max(), dist_5.max(), dist_8.max()) * 1.05, 40)
a1.hist(dist_known, bins=bins, color="#4C72B0", alpha=0.85, label="已知 7 档（测试）")
a1.hist(dist_5, bins=bins, color="#C44E52", alpha=0.75, label="未见 12.30 %")
a1.hist(dist_8, bins=bins, color="#8172B3", alpha=0.75, label="未见 37.30 %")
a1.axvline(thr, color="k", ls="--", lw=1.2, label=f"判定阈值 = {thr:.1f}")
a1.set_xlabel("到最近类原型的马氏距离（越大越陌生）", fontsize=9)
a1.set_ylabel("切片数", fontsize=9)
a1.set_title("开集判据：已知 vs 未见过", fontsize=11)
a1.legend(fontsize=8)

E = np.concatenate([fte, fuk])
is_unknown = np.concatenate([np.zeros(len(fte), bool), np.ones(len(fuk), bool)])
Y = tsne(E, perplexity=30, iters=1200)
y_all = np.concatenate([yte, np.full(len(yu), -1)])
for k in range(7):
    m = (~is_unknown) & (y_all == k)
    a2.scatter(Y[m, 0], Y[m, 1], s=34, c=COLORS[k], alpha=0.9, linewidths=0, label=SEV[k] + " %")
m5 = np.zeros(len(E), bool); m5[len(fte):][yu == 5] = True
m8 = np.zeros(len(E), bool); m8[len(fte):][yu == 8] = True
a2.scatter(Y[m5, 0], Y[m5, 1], s=42, marker="x", c="#C44E52", linewidths=1.4, label="未见 12.30 %")
a2.scatter(Y[m8, 0], Y[m8, 1], s=42, marker="x", c="#8172B3", linewidths=1.4, label="未见 37.30 %")
a2.set_xticks([]); a2.set_yticks([])
a2.legend(fontsize=7, ncol=2, loc="best")
a2.set_title("t-SNE：未见档位落在已知簇之间（被判为异常）", fontsize=11)

fig.suptitle("60 Hz 开集识别：7 档训练，两个未参与训练的档位全部判为“异常/未见过”", fontsize=12.5, y=0.99)
fig.tight_layout(rect=(0, 0, 1, 0.94))
fig.savefig("figs/a1_openset_60hz.png", dpi=190)
print("saved")
