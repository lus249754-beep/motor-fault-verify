"""Check t-SNE settings for the unseen 12.30 % group at 60 Hz / 0.07 N.m."""
import numpy as np
import scipy.io as sio
import torch
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from stage2_60hz_007 import CNN, LABELS
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp, y0 = x[m], sp[m], y0[m]
    y = np.array([LABELS.index(int(v)) for v in y0])
    tr, te = sp == "train", sp == "test"
    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)
    X = np.asarray(sio.loadmat("a1_slices/60-0.07-1-A-12.30-slices.mat")["X"], dtype=np.float32)
    m3, s3 = mu.reshape(3, 1), sd.reshape(3, 1)
    xu = np.stack([((resample(X[:, :, k], 1500, axis=0).T - m3) / s3).astype(np.float32)
                   for k in range(X.shape[2])])

    net = CNN()
    net.load_state_dict(torch.load("a1_2stage_60hz_007.pt", map_location="cpu"))
    net.eval()
    with torch.no_grad():
        fte = net(torch.from_numpy(x[te]))[0].numpy()
        fuk = net(torch.from_numpy(xu))[0].numpy()
    nk = len(fte)
    E = np.concatenate([fte, fuk])
    E = E / (np.linalg.norm(E, axis=1, keepdims=True) + 1e-9)

    fig, axes = plt.subplots(2, 2, figsize=(12.5, 10))
    for ax, perp in zip(axes.ravel(), [5, 15, 30, 50]):
        Y = tsne(E, perplexity=perp, iters=1200)
        for c in range(7):
            mm = y[te] == c
            ax.scatter(Y[:nk][mm, 0], Y[:nk][mm, 1], s=45, c=COLORS[c], label=SEV_TXT[c],
                       linewidths=0)
        ax.scatter(Y[nk:, 0], Y[nk:, 1], s=20, marker="x", c="#B22222", linewidths=0.9,
                   alpha=0.85, label="12.30")
        ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(f"perplexity = {perp}", fontsize=11)
    axes[0, 0].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig("figs/tsne_007_perp.png", dpi=110)
    print("saved")


if __name__ == "__main__":
    main()
