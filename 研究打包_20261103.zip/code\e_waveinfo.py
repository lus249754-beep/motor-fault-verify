"""Print the WaveInfo header block of a DL850 MAT record."""
import re
import sys

import scipy.io as sio


def main(path):
    w = sio.loadmat(path, variable_names=["WaveInfo"])["WaveInfo"]
    text = w.ravel()[0] if w.size else ""
    for line in str(text).splitlines():
        line = line.strip()
        if line:
            print(line)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python e_waveinfo.py <file.MAT>")
        sys.exit(2)
    main(sys.argv[1])
