"""Final open-set detector in RAW physical feature space (no smoothing, no learned embedding).

Known  7 classes, 60 Hz / 0.07 N.m.
Unseen 12.30 %: I2/I1 = 0.052, between 8.33 % (0.035) and 20.64 % (0.089).
"""
import json

import numpy as np
import scipy.io as sio
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from deep_feat import physics_features
from reason_harm import extra_features
from openset_final import unseen_features, LABELS

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV = np.array([1.98, 3.97, 5.95, 8.33, 20.64, 28.97, 45.63])
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    F = np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1)
    Fu = unseen_features()

    mu, sd = F[tr].mean(0), F[tr].std(0) + 1e-6
    Z, Zu = (F - mu) / sd, (Fu - mu) / sd
    proto = np.stack([Z[tr & (y == c)].mean(0) for c in range(7)])
    icov = np.linalg.inv(np.cov((Z[tr] - proto[y[tr]]).T) + 1e-3 * np.eye(Z.shape[1]))

    dm = lambda A: np.stack([np.einsum("ij,jk,ik->i", A - proto[c], icov, A - proto[c])
                             for c in range(7)]).min(0)
    dva, dte, du = dm(Z[va]), dm(Z[te]), dm(Zu)
    thr = float(np.quantile(dva, 0.99))
    ka = float((dte < thr).mean())
    ur = float((du >= thr).mean())
    print(f"threshold {thr:.1f} | known accept {ka:.3f} | unseen reject {ur:.3f}")

    # stage-2 regression predictions (trained earlier on smoothed features)
    r = np.load("a1_reg_arrays.npz", allow_pickle=True)
    ru = r["ru"]
    in_band = float(((ru > SEV[3]) & (ru < SEV[4])).mean())
    print(f"stage2: median {np.median(ru):.2f} % | in band {in_band:.3f}")
    json.dump({"mahalanobis_threshold": thr, "known_accept": ka, "unknown_reject": ur,
               "stage2_median": float(np.median(ru)), "stage2_in_band": in_band,
               "n_unseen": int(len(ru))}, open("a1_final_openset.json", "w"), indent=2)

    # ---------------- figure
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.4, 5.8), gridspec_kw={"width_ratios": [1.25, 1]})
    rng = np.random.RandomState(0)
    for c in range(7):
        v = F[y == c, 0][te[y == c]]
        a1.scatter(SEV[c] + rng.uniform(-0.6, 0.6, len(v)), v, s=26, c=COLORS[c], alpha=0.8,
                   linewidths=0, label=f"{SEV_TXT[c]} %")
    a1.scatter(np.full(len(Fu), 12.3) + rng.uniform(-0.5, 0.5, len(Fu)), Fu[:, 0], s=30,
               marker="x", c="#B22222", linewidths=1.0, alpha=0.9, label="12.30 %（未训练）")
    a1.set_yscale("log")
    a1.set_xscale("log")
    a1.set_xticks(SEV)
    a1.set_xticklabels(SEV_TXT, rotation=45, ha="right", fontsize=8)
    a1.set_xlabel("严重度（%）", fontsize=10)
    a1.set_ylabel("负序比 I2/I1", fontsize=10)
    a1.set_title("物理判据：未见档位的负序比夹在第 4 档与第 6 档之间", fontsize=11)
    a1.legend(fontsize=7.5, ncol=2, loc="best")
    a1.grid(alpha=0.25, which="both")

    bins = np.logspace(1, np.log10(max(du.max(), dte.max()) * 1.2), 40)
    a2.hist(dte, bins=bins, color="#4C72B0", alpha=0.85, label="已知（测试）")
    a2.hist(du, bins=bins, color="#C44E52", alpha=0.85, label="未见 12.30 %")
    a2.axvline(thr, color="k", ls="--", lw=1.2, label=f"阈值 = {thr:.0f}")
    a2.set_xscale("log")
    a2.set_xlabel("到最近已知类原型的马氏距离（对数）", fontsize=10)
    a2.set_ylabel("切片数", fontsize=10)
    a2.set_title(f"开集判据：已知接受 {ka*100:.0f}%，未见拒绝 {ur*100:.0f}%", fontsize=11)
    a2.legend(fontsize=8.5)
    fig.suptitle("60 Hz / 0.07 N·m：开集拒绝（物理特征）+ 严重度回归定位到第 5 档", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig("figs/a1_final_openset.png", dpi=190)
    print("saved")


if __name__ == "__main__":
    main()
