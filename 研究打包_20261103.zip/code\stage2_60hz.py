"""Two-stage diagnosis at 60 Hz.

Stage 1 : 7-class CNN + Mahalanobis rejection  -> "unseen" for unknown severities
Stage 2 : severity regression head on the same features -> where does it fall?
          predicted severity inside (8.33 %, 20.64 %) => "第5档 (between 4 and 6)"

Only class 5 (12.30 %) is used as the unseen input; class 8 is ignored entirely.
"""
import glob
import json
import os

import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = np.array([1.98, 3.97, 5.95, 8.33, 20.64, 28.97, 45.63])
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
GAP = (3, 4)          # index 3 = 8.33 %, index 4 = 20.64 %  -> the "5th" level lies between
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 32, 11, 2, 5), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 9, 2, 4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 7, 2, 3), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.feat = nn.Linear(128, 96)
        self.proj = nn.Sequential(nn.Linear(96, 64), nn.ReLU(), nn.Linear(64, 32))
        self.fc = nn.Linear(96, n_cls)
        self.reg = nn.Linear(96, 1)

    def forward(self, x):
        h = self.body(x).flatten(1)
        f = self.feat(h)
        return f, self.proj(f), self.fc(f), self.reg(f).squeeze(1)


def supcon(z, y, t=0.1):
    z = F.normalize(z, 1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def load_unknown(mean, std):
    files = [f for f in sorted(glob.glob("a1_slices/*-slices.mat"))
             if os.path.basename(f).startswith("60-") and "-A-12.30-slices" in f]
    xs = []
    m3, s3 = mean.reshape(3, 1), std.reshape(3, 1)
    for f in files:
        X = np.asarray(sio.loadmat(f)["X"], dtype=np.float32)[:, :, ::3]
        for k in range(X.shape[2]):
            y = resample(X[:, :, k], 1500, axis=0).T
            xs.append(((y - m3) / s3).astype(np.float32))
    print("unseen 12.30 % slices", len(xs), flush=True)
    return np.stack(xs)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed = d["X"], d["y"], d["record"], d["speed"]
    m = np.isclose(speed, 60.0)
    x, rec = x[m], rec[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    keep = np.zeros(len(y), bool)
    for r in set(rec):
        idx = np.flatnonzero(rec == r)
        keep[idx[::3]] = True
    x, y = x[keep], y[keep]

    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        n = len(idx)
        te[idx[:int(0.15 * n)]] = True
        va[idx[int(0.15 * n):int(0.30 * n)]] = True
        tr[idx[int(0.30 * n):]] = True

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)
    xu = load_unknown(mu, sd)

    X, Y = torch.from_numpy(x), torch.from_numpy(y)
    tgt = torch.from_numpy(np.log(SEV)[y].astype(np.float32))
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    epochs = 120
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(X[s], int(torch.randint(-100, 101, (1,))), dims=2)
            f, z, out, r = net(xb)
            loss = (F.cross_entropy(out, Y[s], label_smoothing=0.03)
                    + 0.5 * supcon(z, Y[s])
                    + 0.5 * F.smooth_l1_loss(r, tgt[s]))
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == Y[s]).sum().item(); tot += len(s)
        sched.step(); net.eval()
        with torch.no_grad():
            vacc = float((net(X[va])[2].argmax(1).numpy() == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()

    def run(a):
        with torch.no_grad():
            f, _, logit, r = net(torch.from_numpy(a))
        return f.numpy(), logit.numpy(), np.exp(r.numpy())

    ftr, _, rtr = run(x[tr])
    fva, lva, rva = run(x[va])
    fte, lte, rte = run(x[te])
    fuk, luk, ruk = run(xu)

    proto = np.stack([ftr[y[tr] == c].mean(0) for c in range(7)])
    r0 = ftr - proto[y[tr]]
    icov = np.linalg.inv(np.cov(r0.T) + 1e-3 * np.eye(ftr.shape[1]))

    def mahal(f):
        dd = np.stack([np.einsum("ij,jk,ik->i", f - proto[c], icov, f - proto[c]) for c in range(7)])
        return dd.min(0)

    thr = float(np.quantile(mahal(fva), 0.99))
    known_accept = float((mahal(fte) < thr).mean())
    unknown_reject = float((mahal(fuk) >= thr).mean())
    acc = float((lte.argmax(1) == y[te]).mean())
    mae_known = float(np.mean(np.abs(rte - SEV[y[te]])))

    lo, hi = SEV[GAP[0]], SEV[GAP[1]]
    in_gap = (ruk > lo) & (ruk < hi)
    stage2_acc = float(in_gap.mean())
    print(f"stage1: known accept {known_accept:.3f} unknown reject {unknown_reject:.3f} "
          f"known acc {acc:.3f} MAE {mae_known:.2f} %", flush=True)
    print(f"stage2: 12.30 % predicted inside ({lo}, {hi}) for {stage2_acc:.3f} "
          f"of {len(ruk)} slices, median pred {np.median(ruk):.2f} %", flush=True)

    json.dump({"stage1": {"mahalanobis_threshold": thr, "known_accept": known_accept,
                          "unknown_reject": unknown_reject, "known_acc": acc,
                          "severity_mae_percent": mae_known},
               "stage2": {"band": [lo, hi], "n_unseen": int(len(ruk)),
                          "in_band_fraction": stage2_acc,
                          "median_pred_percent": float(np.median(ruk)),
                          "p10": float(np.percentile(ruk, 10)),
                          "p90": float(np.percentile(ruk, 90))}},
              open("a1_stage2_60hz.json", "w"), indent=1)

    # ---------------- figure
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.4, 5.5), gridspec_kw={"width_ratios": [1, 1.15]})
    a1.scatter(SEV[y[te]], rte, s=30, c="#4C72B0", alpha=0.85, label="已知 7 档（测试）")
    lims = [1.2, 60]
    a1.plot(lims, lims, "k--", lw=1, label="理想 y = x")
    a1.set_xscale("log"); a1.set_yscale("log")
    a1.set_xlim(lims); a1.set_ylim(lims)
    a1.set_xlabel("真实严重度（%）", fontsize=9)
    a1.set_ylabel("回归预测严重度（%）", fontsize=9)
    a1.set_title(f"严重度回归（已知类 MAE = {mae_known:.2f} 个百分点）", fontsize=11)
    a1.legend(fontsize=8)

    a2.hist(ruk, bins=np.logspace(np.log10(3), np.log10(60), 40), color="#C44E52", alpha=0.85)
    a2.axvspan(lo, hi, color="#4C72B0", alpha=0.15)
    a2.axvline(lo, color="#4C72B0", ls="--"); a2.axvline(hi, color="#4C72B0", ls="--")
    a2.set_xscale("log")
    a2.set_xlabel("第二级回归预测的严重度（%）", fontsize=9)
    a2.set_ylabel("切片数", fontsize=9)
    a2.set_title(f"未见 12.30 % 输入：{stage2_acc*100:.1f}% 落在 8.33 %–20.64 % 之间 → 判为第 5 档", fontsize=10.5)
    fig.suptitle("两级诊断：先判“未见异常”，再定位其所在档位区间", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig("figs/a1_stage2_60hz.png", dpi=190)
    torch.save(net.state_dict(), "a1_stage2_model.pt")
    print("saved")


if __name__ == "__main__":
    main()
