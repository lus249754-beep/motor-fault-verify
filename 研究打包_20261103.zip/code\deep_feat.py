"""Physics-feature deep model (MLP + supervised contrastive) -- honest cross-recording test."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from tsne_torch import tsne

LABELS = [1, 2, 3, 4, 6, 7, 9]
FS = 10000.0
torch.manual_seed(0)
np.random.seed(0)


def physics_features(x, speed):
    n, _, N = x.shape
    w = np.hanning(N).astype(np.float32)
    spec = np.fft.rfft(x * w, axis=2)
    a = np.exp(2j * np.pi / 3)
    out = np.zeros((n, 27), np.float32)
    for i in range(n):
        k1 = max(1, int(round(speed[i] / (FS / N))))
        ph = spec[i, :, k1]
        amp = np.abs(ph)
        m = amp.mean() + 1e-9
        I1 = (ph[0] + a * ph[1] + a * a * ph[2]) / 3
        I2 = (ph[0] + a * a * ph[1] + a * ph[2]) / 3
        I0 = ph.sum() / 3
        f = [abs(I2) / (abs(I1) + 1e-9), abs(I0) / (abs(I1) + 1e-9), abs(I1) / m]
        f += list(amp / m)
        for h in (2, 3, 5, 7, 9, 11):
            f += list(np.abs(spec[i, :, h * k1]) / (amp + 1e-9))
        for c in range(3):
            band = np.abs(spec[i, c, k1 + 1:])
            f.append(float(np.sqrt((band ** 2).sum()) / (amp[c] + 1e-9)))
        out[i] = f
    return out


class Net(nn.Module):
    def __init__(self, nf=27, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 128), nn.BatchNorm1d(128), nn.ReLU(),
                                  nn.Dropout(0.3),
                                  nn.Linear(128, 128), nn.BatchNorm1d(128), nn.ReLU())
        self.fc = nn.Linear(128, n_cls)

    def forward(self, x, feat=False):
        z = self.body(x)
        return z if feat else self.fc(z)


def supcon(z, y, t=0.1):
    z = F.normalize(z, 1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    y = np.array([LABELS.index(int(v)) for v in y0])
    cond = np.stack([speed, load], 1)
    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        recs = sorted(set(rec[y == c]))
        rng.shuffle(recs)
        te |= np.isin(rec, recs[:2]); va |= np.isin(rec, recs[2:3]); tr |= np.isin(rec, recs[3:])

    Fp = physics_features(x, speed)
    for key in np.unique(cond, axis=0):
        m = np.all(cond == key, axis=1)
        Fp[m] = (Fp[m] - Fp[m & tr].mean(0)) / (Fp[m & tr].std(0) + 1e-6)
    Fp = ((Fp - Fp[tr].mean(0)) / (Fp[tr].std(0) + 1e-6)).astype(np.float32)

    Xt, yt = torch.from_numpy(Fp), torch.from_numpy(y)
    net = Net()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
    ep_n, bs = 120, 128
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, ep_n)
    idx = np.flatnonzero(tr)
    best_state, best = None, -1.0
    for ep in range(ep_n):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), bs):
            sel = idx[b:b + bs]
            xb = Xt[sel] + 0.05 * torch.randn_like(Xt[sel])
            yb = yt[sel]
            z = net(xb, feat=True)
            out = net.fc(z)
            loss = F.cross_entropy(out, yb) + 0.3 * supcon(z, yb)
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == yb).sum().item(); tot += len(sel)
        sched.step()
        net.eval()
        with torch.no_grad():
            pv = net(Xt[va]).argmax(1).numpy()
        vacc = float((pv == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
        if (ep + 1) % 20 == 0:
            print(f"  ep{ep+1:3d} train {corr/tot:.4f} val {vacc:.4f}", flush=True)
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        pred = net(Xt).argmax(1).numpy()
        emb = net(Xt, feat=True).numpy()

    wacc = float((pred[te] == y[te]).mean())
    votes = {}
    for i in np.flatnonzero(te):
        votes.setdefault(rec[i], []).append(pred[i])
    rc = sum(int(np.bincount(v, minlength=7).argmax() == y[np.flatnonzero(rec == r)[0]])
             for r, v in votes.items())
    racc = rc / len(votes)
    print(f"window {wacc:.4f}  record {racc:.4f} ({rc}/{len(votes)})")

    cm = np.zeros((7, 7), int)
    for i in np.flatnonzero(te):
        cm[y[i], pred[i]] += 1

    recs = sorted(set(rec))
    E = np.stack([emb[rec == r].mean(0) for r in recs])
    Ry = np.array([y[np.flatnonzero(rec == r)[0]] for r in recs])
    Rte = np.array([bool(te[rec == r][0]) for r in recs])
    Y = tsne(E, perplexity=15, iters=1000)
    np.savez("a1_deep_tsne.npz", Y=Y, y=Ry, is_test=Rte, E=E, cm=cm, wacc=wacc, racc=racc)
    json.dump({"window_test_acc": wacc, "record_test_acc": racc, "n_test_records": len(votes),
               "cm": cm.tolist()}, open("a1_deep_metrics.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
