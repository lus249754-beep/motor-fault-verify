"""Figure for the final open-set run (arrays already saved)."""
import json

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV = np.array([1.98, 3.97, 5.95, 8.33, 20.64, 28.97, 45.63])
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]

d = np.load("a1_openset_arrays.npz", allow_pickle=True)
E, Eu, y, te = d["E"], d["Eu"], d["y"], d["te"]
rk, ru, dte, du, gte, gu = d["rk"], d["ru"], d["dte"], d["du"], d["gte"], d["gu"]
va = d["va"]
yva = y[va]

t1 = float(np.quantile(d[["dva"][0]] if False else np.concatenate([[0]]), 0.99)) if False else None
# thresholds from the validation split, as in the sweep
dva = d["dte"][:0] if False else None

# recompute validation scores is not possible here -> use test-side quantiles saved in metrics
m = json.load(open("a1_openset_final.json"))

fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.4, 5.8), gridspec_kw={"width_ratios": [1.45, 1]})
Y = tsne(np.concatenate([E, Eu]), perplexity=30, iters=2000)
nk = len(E)
for c in range(7):
    mm = te & (y == c)
    a1.scatter(Y[:nk][mm, 0], Y[:nk][mm, 1], s=26, c=COLORS[c], alpha=0.85, linewidths=0,
               label=SEV_TXT[c] + " %")
a1.scatter(Y[nk:, 0], Y[nk:, 1], s=20, marker="x", c="#B22222", linewidths=0.9, alpha=0.85,
           label="12.30 %（未训练）")
a1.set_xticks([]); a1.set_yticks([])
a1.legend(fontsize=8, ncol=2, title="严重度", title_fontsize=9)
a1.set_title("t-SNE 嵌入：已知 7 档 + 未见 12.30 %", fontsize=11)

a2.hist(ru, bins=np.linspace(6, 24, 30), color="#C44E52", alpha=0.85, label="未见 12.30 %")
a2.hist(rk[te], bins=np.linspace(6, 24, 30), color="#4C72B0", alpha=0.45, label="已知（测试）")
a2.axvspan(SEV[3], SEV[4], color="#4C72B0", alpha=0.12)
a2.axvline(SEV[3], color="#4C72B0", ls="--"); a2.axvline(SEV[4], color="#4C72B0", ls="--")
a2.set_xlabel("回归预测的严重度（%）"); a2.set_ylabel("切片数")
a2.set_title(f"未见 12.30 %：预测中位数 {np.median(ru):.1f} %，98.8 % 落在 8.33–20.64 %", fontsize=10)
a2.legend(fontsize=8)
fig.suptitle("60 Hz / 0.07 N·m：开集拒绝 + 严重度回归定位（平滑 + 5 模型集成）", fontsize=12.5, y=0.99)
fig.tight_layout(rect=(0, 0, 1, 0.93))
fig.savefig("figs/a1_openset_final2.png", dpi=190)
print("saved")
