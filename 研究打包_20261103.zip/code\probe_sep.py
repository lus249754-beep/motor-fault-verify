"""Quick separability probe on hand-crafted features (no CNN) to find the ceiling."""
import numpy as np
import torch

d = np.load("a1_7cls_10k.npz", allow_pickle=True)
x, y, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
LABELS = [1, 2, 3, 4, 6, 7, 9]
y = np.array([LABELS.index(int(v)) for v in y])

rng = np.random.RandomState(0)
tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
for c in range(7):
    recs = sorted(set(rec[y == c]))
    rng.shuffle(recs)
    te |= np.isin(rec, recs[:2]); va |= np.isin(rec, recs[2:3]); tr |= np.isin(rec, recs[3:])

FS = 10000.0
N = x.shape[2]
w = np.hanning(N).astype(np.float32)
spec = np.fft.rfft(x * w, axis=2)          # (n, 3, 751)
freq = np.fft.rfftfreq(N, 1 / FS)


def feats(i):
    k1 = int(round(speed[i] / (FS / N)))
    ph = spec[i, :, k1]                     # complex phasor per phase
    a1 = np.abs(ph)
    mean1 = a1.mean() + 1e-9
    seq2 = np.abs(ph[0] + ph[1] * np.exp(2j * np.pi / 3) + ph[2] * np.exp(-2j * np.pi / 3)) / (3 * mean1)
    seq0 = np.abs(ph.sum()) / (3 * mean1)
    f = [seq2, seq0]
    f += list(a1 / mean1)                   # per-phase amplitude imbalance
    harm = []
    for h in range(2, 7):
        harm += list(np.abs(spec[i, :, h * k1]) / (a1 + 1e-9))
    f += harm
    for c in range(3):
        band = np.abs(spec[i, c, k1 + 1:])
        f.append(float(np.sqrt((band ** 2).sum()) / (a1[c] + 1e-9)))   # THD
    return np.array(f, dtype=np.float32)


F = np.stack([feats(i) for i in range(len(y))])
F = (F - F[tr].mean(0)) / (F[tr].std(0) + 1e-6)
print("features", F.shape)

net = torch.nn.Sequential(torch.nn.Linear(F.shape[1], 64), torch.nn.ReLU(),
                          torch.nn.Linear(64, 7))
opt = torch.optim.Adam(net.parameters(), lr=1e-2, weight_decay=1e-3)
Xt, yt = torch.from_numpy(F), torch.from_numpy(y)
for ep in range(300):
    net.train()
    opt.zero_grad()
    loss = torch.nn.functional.cross_entropy(net(Xt[tr]), yt[tr])
    loss.backward()
    opt.step()
net.eval()
with torch.no_grad():
    p = net(Xt).argmax(1).numpy()
print("linear-ish probe: train %.3f val %.3f test %.3f" % (
    (p[tr] == y[tr]).mean(), (p[va] == y[va]).mean(), (p[te] == y[te]).mean()))
