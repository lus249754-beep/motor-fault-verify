"""Compare the four load points at 60 Hz; pick the one where severity separates best."""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

LABELS = [1, 2, 3, 4, 6, 7, 9]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 32, 11, 2, 5), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 9, 2, 4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 7, 2, 3), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.feat = nn.Linear(128, 96)
        self.fc = nn.Linear(96, n_cls)

    def forward(self, x):
        return self.fc(self.feat(self.body(x).flatten(1)))


def run(x, y, tr, va, te, epochs=100):
    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)
    X, Y = torch.from_numpy(x), torch.from_numpy(y)
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx)
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(X[s], int(torch.randint(-100, 101, (1,))), dims=2)
            loss = F.cross_entropy(net(xb), Y[s], label_smoothing=0.03)
            opt.zero_grad(); loss.backward(); opt.step()
        sched.step(); net.eval()
        with torch.no_grad():
            vacc = float((net(X[va]).argmax(1).numpy() == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        pred = net(X[te]).argmax(1).numpy()
    return float((pred == y[te]).mean()), float((pred == y[va]).mean())


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m60 = np.isclose(speed, 60.0)
    print(f"{'load (N.m)':>10s} {'train':>6s} {'val':>6s} {'test':>6s}")
    for L in sorted(set(np.round(load[m60], 2))):
        k = m60 & np.isclose(load, L)
        xx, yy, ss = x[k], np.array([LABELS.index(int(v)) for v in y0[k]]), sp[k]
        tr, va, te = ss == "train", ss == "val", ss == "test"
        acc, vacc = run(xx, yy, tr, va, te)
        print(f"{L:10.2f} {tr.sum():6d} {va.sum():6d} {te.sum():6d}   test {acc:.3f}  val {vacc:.3f}",
              flush=True)


if __name__ == "__main__":
    main()
