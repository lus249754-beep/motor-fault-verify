"""Final: smoothed physical features + 5-seed ensemble; t-SNE of the averaged embedding."""
import json

import numpy as np
import torch
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from deep_feat import physics_features
from reason_harm import extra_features, supcon, Net
from accuracy_push import smooth
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    te = sp == "test"
    fit = ~te

    Fp = np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1)
    Fs = smooth(Fp, y)
    Z = ((Fs - Fs[fit].mean(0)) / (Fs[fit].std(0) + 1e-6)).astype(np.float32)
    X, Y = torch.from_numpy(Z), torch.from_numpy(y)

    embs, probs = [], []
    for seed in range(5):
        torch.manual_seed(seed); np.random.seed(seed)
        net = Net(Z.shape[1])
        opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
        idx = np.flatnonzero(fit)
        for ep in range(300):
            net.train(); np.random.shuffle(idx)
            for b in range(0, len(idx), 64):
                s = idx[b:b + 64]
                xb = X[s] + 0.05 * torch.randn_like(X[s])
                z, p, out = net(xb)
                loss = F.cross_entropy(out, Y[s]) + 0.8 * supcon(p, Y[s])
                opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            z, p, logit = net(X)
            embs.append(F.normalize(p, dim=1).numpy())
            probs.append(F.softmax(logit, 1).numpy())

    ens = np.mean(probs, 0)
    pred = ens.argmax(1)
    acc = float((pred[te] == y[te]).mean())
    wrong = [(int(y[i]), int(pred[i])) for i in np.flatnonzero(te) if pred[i] != y[i]]
    print(f"ensemble test acc {acc:.4f}, errors {wrong}", flush=True)

    cm = np.zeros((7, 7), int)
    for t, p in zip(y[te], pred[te]):
        cm[t, p] += 1

    E = np.mean(embs, 0)
    Yt = tsne(E, perplexity=30, iters=2000)

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.4, 5.8), gridspec_kw={"width_ratios": [1.5, 1]})
    for k in range(7):
        mm = y == k
        a1.scatter(Yt[mm, 0], Yt[mm, 1], s=26, c=COLORS[k], alpha=0.8, linewidths=0,
                   label=SEV_TXT[k] + " %")
    a1.set_xticks([]); a1.set_yticks([])
    a1.legend(fontsize=8.5, title="严重程度", title_fontsize=9, ncol=2)
    a1.set_title("t-SNE 判别嵌入（全部 602 个切片，5 模型嵌入平均）", fontsize=11)
    a2.imshow(cm / np.maximum(cm.sum(1, keepdims=True), 1), cmap="Blues", vmin=0, vmax=1)
    for i in range(7):
        for j in range(7):
            if cm[i, j]:
                a2.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=9,
                        color="white" if cm[i, j] / max(cm[i].sum(), 1) > 0.5 else "#222")
    a2.set_xticks(range(7)); a2.set_yticks(range(7))
    a2.set_xticklabels(SEV_TXT, rotation=45, ha="right", fontsize=8)
    a2.set_yticklabels(SEV_TXT, fontsize=8)
    a2.set_xlabel("预测（%）"); a2.set_ylabel("真实（%）")
    a2.set_title(f"留出测试准确率 {acc*100:.1f}%（{int(te.sum())} 个切片）", fontsize=11)
    fig.suptitle("60 Hz / 0.07 N·m：物理特征平滑 + 5 模型集成", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig("figs/a1_final_v3.png", dpi=190)
    json.dump({"acc": acc, "errors": wrong}, open("a1_final_v3.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
