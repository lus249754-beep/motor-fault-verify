"""20 Hz: compare simple-CNN input configurations (all with per-window conditioning)."""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

LABELS = [1, 2, 3, 4, 6, 7, 9]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, cin=3, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(cin, 16, 9, 2, 4), nn.BatchNorm1d(16), nn.ReLU(),
            nn.Conv1d(16, 32, 7, 2, 3), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 5, 2, 2), nn.BatchNorm1d(64), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.fc = nn.Linear(64, n_cls)

    def forward(self, x):
        return self.fc(self.body(x).flatten(1))


def run(x, y, rec, tr, te, extra=None, epochs=120, lr=5e-4):
    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = (x - mu) / sd
    if extra is not None:
        e = extra[:, :, None].repeat(x.shape[2], axis=2)
        x = np.concatenate([x, e], axis=1)
    X, Y = torch.from_numpy(x.astype(np.float32)), torch.from_numpy(y)
    net = CNN(cin=x.shape[1])
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=5e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx)
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(X[s], int(torch.randint(-200, 201, (1,))), dims=2)
            out = net(xb)
            loss = F.cross_entropy(out, Y[s], label_smoothing=0.03)
            opt.zero_grad(); loss.backward(); opt.step()
        sched.step()
    net.eval()
    with torch.no_grad():
        p = net(X).argmax(1).numpy()
    w = float((p[te] == y[te]).mean())
    votes = {}
    for i in np.flatnonzero(te):
        votes.setdefault(rec[i], []).append(p[i])
    rc = sum(int(np.bincount(v, minlength=7).argmax() == y[np.flatnonzero(rec == r)[0]])
             for r, v in votes.items())
    return w, rc / len(votes), (p[tr] == y[tr]).mean()


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    m = np.isclose(speed, 20.0)
    x, rec, load = x[m], rec[m], load[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])

    x = x - x.mean(axis=2, keepdims=True)
    rms = np.sqrt((x ** 2).mean(axis=2, keepdims=True))
    xn = (x / (rms.mean(axis=1, keepdims=True) + 1e-9)).astype(np.float32)
    ld = ((load - 0.07) / (34.14 - 0.07)).astype(np.float32)

    rng = np.random.RandomState(0)
    te = np.zeros(len(y), bool)
    for c in range(7):
        recs = sorted(set(rec[y == c]))
        rng.shuffle(recs)
        te |= np.isin(rec, recs[:1])

    print("A normalized, random record", run(xn, y, rec, ~te, te))
    print("B normalized + load channel", run(xn, y, rec, ~te, te,
                                             extra=np.stack([ld, ld], 1)))
    print("C raw amplitude, random record", run(x, y, rec, ~te, te))


if __name__ == "__main__":
    main()
