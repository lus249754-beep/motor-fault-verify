"""NN open-set: virtual outlier synthesis between adjacent severity levels + binary head."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from deep_feat import physics_features
from reason_harm import extra_features
from accuracy_push import smooth
from openset_final import unseen_features, LABELS, SEV

np.random.seed(0)
torch.manual_seed(0)


class Net(nn.Module):
    def __init__(self, nf):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(0.2),
                                  nn.Linear(128, 128), nn.BatchNorm1d(128), nn.ReLU())
        self.fc = nn.Linear(128, 7)
        self.reg = nn.Linear(128, 1)
        self.bin = nn.Linear(128, 1)

    def forward(self, x):
        z = self.body(x)
        return self.fc(z), self.reg(z).squeeze(1), self.bin(z).squeeze(1)


def mix_between(X, Y, n, rng):
    """linear mixtures of features from adjacent severity levels -> virtual 'between' samples"""
    pairs = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6)]
    out = []
    for _ in range(n):
        a, b = pairs[rng.randint(len(pairs))]
        ia = rng.choice(np.flatnonzero(Y == a))
        ib = rng.choice(np.flatnonzero(Y == b))
        lam = rng.uniform(0.3, 0.7)
        out.append(lam * X[ia] + (1 - lam) * X[ib])
    return torch.from_numpy(np.stack(out).astype(np.float32))


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    Fs = smooth(np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1), y)
    Fu_raw = unseen_features()
    Fu = smooth(Fu_raw, np.zeros(len(Fu_raw), int))
    mu, sd = Fs[tr].mean(0), Fs[tr].std(0) + 1e-6
    Z = ((Fs - mu) / sd).astype(np.float32)
    Zu = ((Fu - mu) / sd).astype(np.float32)

    Xt, Yt = torch.from_numpy(Z), torch.from_numpy(y)
    tgt = torch.from_numpy(np.log(SEV)[y].astype(np.float32))
    others_k, others_u, accs = [], [], []
    for seed in range(5):
        torch.manual_seed(seed); np.random.seed(seed)
        rng = np.random.RandomState(seed)
        net = Net(Z.shape[1])
        opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
        idx = np.flatnonzero(tr)
        for ep in range(300):
            net.train(); np.random.shuffle(idx)
            for b in range(0, len(idx), 80):
                s = idx[b:b + 80]
                xb = Xt[s] + 0.03 * torch.randn_like(Xt[s])
                xo = mix_between(Z, y, 40, rng)
                opt.zero_grad()
                lo, ro, bo = net(xb)
                _, _, bu = net(xo)
                loss = (F.cross_entropy(lo, Yt[s]) + 0.5 * F.mse_loss(ro, tgt[s])
                        + 0.5 * (F.binary_cross_entropy_with_logits(bo, torch.ones_like(bo))
                                 + F.binary_cross_entropy_with_logits(bu, torch.zeros_like(bu))))
                loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            lk, _, bk = net(Xt)
            _, _, bu = net(torch.from_numpy(Zu))
        others_k.append(bk.numpy()); others_u.append(bu.numpy())
        accs.append(float((lk.argmax(1).numpy()[te] == y[te]).mean()))
    sk = np.mean(others_k, 0)      # higher = more "known"
    su = np.mean(others_u, 0)
    acc = float((np.mean([0], 0) if False else 0))
    print(f"per-seed acc {np.mean(accs):.4f} best {np.max(accs):.4f}")
    print(f"binary score: known median {np.median(sk[te]):.3f} unseen median {np.median(su):.3f}")

    for keep in (0.99, 0.98, 0.95):
        thr = float(np.quantile(sk[va], 1 - keep))
        ka = float((sk[te] >= thr).mean())
        ur = float((su < thr).mean())
        print(f"keep {keep:.2f} thr {thr:+.3f} known accept {ka:.3f} unseen reject {ur:.3f}", flush=True)
    np.savez("a1_vos_arrays.npz", sk=sk, su=su, y=y, te=te, va=va, acc=np.array(accs))
    json.dump({"acc_single": float(np.mean(accs))}, open("a1_vos.json", "w"), indent=1)


if __name__ == "__main__":
    main()
