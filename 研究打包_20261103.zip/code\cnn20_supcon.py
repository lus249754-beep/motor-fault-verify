"""20 Hz slice-level CNN + supervised contrastive head, then t-SNE of the projection."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

from tsne_adam import tsne

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 32, 11, 2, 5), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 9, 2, 4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 7, 2, 3), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.feat = nn.Linear(128, 96)
        self.proj = nn.Sequential(nn.Linear(96, 64), nn.ReLU(), nn.Linear(64, 32))
        self.fc = nn.Linear(96, n_cls)

    def forward(self, x):
        h = self.body(x).flatten(1)
        f = self.feat(h)
        return f, self.proj(f), self.fc(f)


def supcon(z, y, t=0.1):
    z = F.normalize(z, 1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed = d["X"], d["y"], d["record"], d["speed"]
    m = np.isclose(speed, 20.0)
    x, rec = x[m], rec[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    keep = np.zeros(len(y), bool)
    for r in set(rec):
        idx = np.flatnonzero(rec == r)
        keep[idx[::3]] = True
    x, y = x[keep], y[keep]

    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        n = len(idx)
        te[idx[:int(0.15 * n)]] = True
        va[idx[int(0.15 * n):int(0.30 * n)]] = True
        tr[idx[int(0.30 * n):]] = True

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)
    X, Y = torch.from_numpy(x), torch.from_numpy(y)

    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    epochs = 120
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(X[s], int(torch.randint(-100, 101, (1,))), dims=2)
            f, z, out = net(xb)
            loss = F.cross_entropy(out, Y[s], label_smoothing=0.03) + 0.5 * supcon(z, Y[s])
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == Y[s]).sum().item(); tot += len(s)
        sched.step(); net.eval()
        with torch.no_grad():
            _, _, ov = net(X[va])
            vacc = float((ov.argmax(1).numpy() == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        logit = sum(net(torch.roll(X, s, dims=2))[2] for s in (0, -50, 50)) / 3
        pred = logit.argmax(1).numpy()
        emb = net(X)[1].numpy()          # 32-d projection head
    acc = float((pred[te] == y[te]).mean())
    print("test acc %.4f" % acc, flush=True)

    cm = np.zeros((7, 7), int)
    for t, p in zip(y[te], pred[te]):
        cm[t, p] += 1

    Ys = tsne(emb[te], perplexity=22, iters=1500)
    np.savez("a1_20hz_supcon_tsne.npz", Y=Ys, y=y[te], cm=cm, acc=acc)
    json.dump({"acc": acc}, open("a1_20hz_supcon_metrics.json", "w"), indent=1)

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5.4), gridspec_kw={"width_ratios": [1.35, 1]})
    for k in range(7):
        a1.scatter(Ys[y[te] == k, 0], Ys[y[te] == k, 1], s=38, c=COLORS[k], alpha=0.88,
                   linewidths=0, label=SEV[k] + " %")
    a1.set_xticks([]); a1.set_yticks([])
    a1.legend(fontsize=8, title="严重程度", title_fontsize=9, loc="best")
    a1.set_title(f"t-SNE 特征分布（20 Hz 测试切片 n={int(te.sum())}）", fontsize=11)
    cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
    a2.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
    for i in range(7):
        for j in range(7):
            if cm[i, j]:
                a2.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=9,
                        color="white" if cmn[i, j] > 0.5 else "#222")
    a2.set_xticks(range(7)); a2.set_yticks(range(7))
    a2.set_xticklabels(SEV, rotation=45, ha="right", fontsize=8)
    a2.set_yticklabels(SEV, fontsize=8)
    a2.set_xlabel("预测（%）"); a2.set_ylabel("真实（%）")
    a2.set_title(f"混淆矩阵（准确率 {acc*100:.2f}%）", fontsize=11)
    fig.suptitle("20 Hz 单工况：CNN + 监督对比损失", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig("figs/a1_20hz_supcon.png", dpi=190)
    print("saved")


if __name__ == "__main__":
    main()
