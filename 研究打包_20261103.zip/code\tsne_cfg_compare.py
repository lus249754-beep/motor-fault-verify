"""Try several embeddings / perplexities and see which keeps the unseen level compact."""
import glob
import os

import numpy as np
import scipy.io as sio
import torch
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from stage2_60hz import CNN, LABELS
from tsne_adam import tsne

SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0)
    x, rec, load = x[m], rec[m], load[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    keep = np.zeros(len(y), bool)
    for r in set(rec):
        idx = np.flatnonzero(rec == r)
        keep[idx[::3]] = True
    x, y, load = x[keep], y[keep], load[keep]

    rng = np.random.RandomState(0)
    te = np.zeros(len(y), bool); tr = np.zeros(len(y), bool)
    for c in range(7):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        n = len(idx)
        te[idx[:int(0.15 * n)]] = True
        tr[idx[int(0.30 * n):]] = True

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    files = [f for f in sorted(glob.glob("a1_slices/*-slices.mat"))
             if os.path.basename(f).startswith("60-") and "-A-12.30-slices" in f]
    xs = []
    m3, s3 = mu.reshape(3, 1), sd.reshape(3, 1)
    for f in files:
        X = np.asarray(sio.loadmat(f)["X"], dtype=np.float32)[:, :, ::3]
        for k in range(X.shape[2]):
            yy = resample(X[:, :, k], 1500, axis=0).T
            xs.append(((yy - m3) / s3).astype(np.float32))
    xu = np.stack(xs)

    net = CNN()
    net.load_state_dict(torch.load("a1_stage2_model.pt", map_location="cpu"))
    net.eval()

    def embed(a):
        with torch.no_grad():
            f, z, _, _ = net(torch.from_numpy(a))
        return f.numpy(), z.numpy()

    fte, zte = embed(x[te])
    fuk, zuk = embed(xu)
    nk = len(fte)

    cfgs = [("feat 96-d, perp 10", fte, fuk, 10),
            ("feat 96-d, perp 40", fte, fuk, 40),
            ("proj 32-d, perp 10", zte, zuk, 10),
            ("proj 32-d, perp 30", zte, zuk, 30)]
    fig, axes = plt.subplots(2, 2, figsize=(13, 10))
    for ax, (name, a, b, perp) in zip(axes.ravel(), cfgs):
        E = np.concatenate([a, b])
        E = E / (np.linalg.norm(E, axis=1, keepdims=True) + 1e-9)
        Y = tsne(E, perplexity=perp, iters=1200)
        for c in range(7):
            mm = y[te] == c
            ax.scatter(Y[:nk][mm, 0], Y[:nk][mm, 1], s=38, c=COLORS[c],
                       label=SEV_TXT[c], linewidths=0)
        ax.scatter(Y[nk:, 0], Y[nk:, 1], s=16, marker="x", c="#B22222", linewidths=0.8,
                   alpha=0.8, label="12.30 %")
        ax.set_xticks([]); ax.set_yticks([])
        ax.set_title(name, fontsize=11)
    axes[0, 0].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig("figs/tsne_cfg_compare.png", dpi=110)
    print("saved")


if __name__ == "__main__":
    main()
