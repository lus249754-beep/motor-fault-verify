"""Extract a readable transcript (user + assistant text) from the DSH session JSONL."""
import json
import os
import sys


def text_of(content):
    out = []
    for part in content or []:
        if not isinstance(part, dict):
            continue
        if part.get("type") == "text":
            out.append(part.get("text", ""))
    return "\n".join(out).strip()


def main(src, dst):
    rows = [json.loads(line) for line in open(src, encoding="utf-8")]
    seq = []
    for r in rows:
        t = r.get("type")
        if t == "user/message":
            d = r["data"]
            tx = text_of(d.get("content"))
            if ("Current runtime context" in tx or "<system-reminder>" in tx
                    or tx.startswith("Time sampled")):
                continue
            seq.append(("user", d.get("turn"), tx))
        elif t == "assistant/message":
            d = r["data"]
            seq.append(("assistant", d.get("turn"), text_of(d["message"].get("content"))))
    lines = ["# 与 AI 助手的完整对话记录", "",
             "> 由会话日志自动导出，只保留双方的文字内容，省略工具调用与内部推理。", ""]
    last_turn = None
    for role, turn, txt in seq:
        if not txt:
            continue
        if turn != last_turn:
            lines.append(f"\n## 第 {turn} 轮\n")
            last_turn = turn
        who = "**用户**" if role == "user" else "**助手**"
        lines.append(f"{who}：\n\n{txt}\n")
    open(dst, "w", encoding="utf-8").write("\n".join(lines))
    print("wrote", dst, os.path.getsize(dst) // 1024, "KB,", len(lines), "lines")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
