"""Read one record from each E: folder and report signal statistics."""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mat5 import Mat5

WANT = ("CH01", "CH02", "CH03", "CH04", "CH05", "CH06", "CH08")


def read_channels(path, want=WANT):
    m = Mat5(path)
    out = {}
    pos = 128
    while pos < m.size - 8:
        t = m.tag(pos)
        if t is None or not (1 <= t[0] <= 30):
            break
        typ, size, dpos, end = t
        if typ == 14:
            name, val = m.matrix(pos)
            if name in want and val is not None:
                out[name] = np.asarray(val, dtype=np.float64).ravel()
        pos = m._advance(pos, dpos, size)
    m.close()
    return out


def stats(path, label):
    ch = read_channels(path)
    print(f"\n=== {label} ===")
    print(f"  {os.path.basename(path)}  {os.path.getsize(path)/1e6:.1f} MB")
    for k in WANT:
        if k not in ch:
            continue
        x = ch[k]
        rms = float(np.sqrt(np.mean(x ** 2)))
        print(f"  {k}: n={x.size:>8d}  mean={x.mean():+.4g}  std={x.std():.4g}  "
              f"rms={rms:.4g}  min={x.min():+.4g}  max={x.max():+.4g}")
    if all(k in ch for k in ("CH02", "CH04", "CH06")):
        i = np.column_stack([ch["CH02"], ch["CH04"], ch["CH06"]])
        rms = np.sqrt(np.mean(i ** 2, axis=0))
        print(f"  phase-current RMS (A) = {np.round(rms, 4).tolist()}")
        print(f"  negative/zero sequence ratio = {(1 - rms.min()/rms.max()):.3%} spread")
        fund = np.fft.rfft(i[500_000:1_500_000, 0] * np.hanning(1_000_000))
        f = np.fft.rfftfreq(1_000_000, 1e-6)
        print(f"  dominant freq of CH02 = {f[np.argmax(np.abs(fund))]:.2f} Hz")


def main():
    base = r"E:"
    for folder, fn in [
        ("A0.01", "20-0.07-0.01-A-1.98-FOC.MAT"),
        ("A1", "20-0.07-1-A-1.98-FOC.MAT"),
        ("A10", "20-0.07-10-A-1.98-FOC.MAT"),
    ]:
        p = os.path.join(base, folder, fn)
        if os.path.exists(p):
            stats(p, folder)
        else:
            print("missing", p)
    hp = r"C:\Users\Lenovo\Documents\deepseek-harness\default-workspace\health_data\Health\20-0.07-0-Health-0-FOC.MAT"
    stats(hp, "Health (20 Hz, 0.07 Nm)")


if __name__ == "__main__":
    main()
