"""Simplest 1D-CNN on 20 Hz-only windows (7 severity classes, record-level holdout)."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from tsne_adam import tsne

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 16, 9, 2, 4), nn.BatchNorm1d(16), nn.ReLU(),
            nn.Conv1d(16, 32, 7, 2, 3), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 5, 2, 2), nn.BatchNorm1d(64), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.fc = nn.Linear(64, n_cls)

    def forward(self, x, feat=False):
        z = self.body(x).flatten(1)
        return z if feat else self.fc(z)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    m20 = np.isclose(speed, 20.0)
    x, rec, load = x[m20], rec[m20], load[m20]
    y = np.array([LABELS.index(int(v)) for v in y0[m20]])
    print("20 Hz windows", x.shape, "records", len(set(rec)), flush=True)

    # unseen condition inside 20 Hz: whole 34.14 Nm load is held out
    te = np.isclose(load, 34.14)
    tr = ~te
    print("train windows", tr.sum(), "test windows", te.sum(),
          "test records", len(set(rec[te])), flush=True)

    # per-window conditioning: remove DC, scale by the window's mean phase RMS
    x = x - x.mean(axis=2, keepdims=True)
    rms = np.sqrt((x ** 2).mean(axis=2, keepdims=True))
    x = (x / (rms.mean(axis=1, keepdims=True) + 1e-9)).astype(np.float32)
    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    Xt, yt = torch.from_numpy(x), torch.from_numpy(y)
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=5e-4, weight_decay=5e-3)
    epochs = 150
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = Xt[s]
            xb = torch.roll(xb, int(torch.randint(-200, 201, (1,))), dims=2)
            xb = xb + 0.02 * torch.randn_like(xb)
            out = net(xb)
            loss = F.cross_entropy(out, yt[s], label_smoothing=0.03)
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == yt[s]).sum().item(); tot += len(s)
        sched.step()
        if (ep + 1) % 20 == 0:
            net.eval()
            with torch.no_grad():
                ptr = net(Xt[tr]).argmax(1).numpy()
            print(f"  ep{ep+1:3d} train {corr/tot:.4f} fit {float((ptr==y[tr]).mean()):.4f}", flush=True)
    net.eval()
    with torch.no_grad():
        pred = net(Xt[te]).argmax(1).numpy()
        emb = net(Xt, feat=True).numpy()
    acc = float((pred == y[te]).mean())
    print("test acc %.4f" % acc)

    cm = np.zeros((7, 7), int)
    for t, p in zip(y[te], pred):
        cm[t, p] += 1

    recs = sorted(set(rec))
    E = np.stack([emb[rec == r].mean(0) for r in recs])
    Ry = np.array([y[np.flatnonzero(rec == r)[0]] for r in recs])
    Rte = np.array([bool(te[rec == r][0]) for r in recs])
    Y = tsne(E, perplexity=8, iters=1200)
    np.savez("a1_20hz_tsne.npz", Y=Y, y=Ry, is_test=Rte, cm=cm, acc=acc)
    json.dump({"acc": acc, "n_train": int(tr.sum()), "n_test": int(te.sum())},
              open("a1_20hz_metrics.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
