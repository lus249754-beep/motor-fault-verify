"""t-SNE (record level) + confusion matrix for the physics-feature deep model."""
import json

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]

d = np.load("a1_deep_tsne.npz", allow_pickle=True)
Y, y, is_te, cm = d["Y"], d["y"], d["is_test"], d["cm"]
m = json.load(open("a1_deep_metrics.json"))

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.6, 6.0), gridspec_kw={"width_ratios": [1.35, 1]})
for c in range(7):
    for mask, mk, ms, lab in [(~is_te, "o", 55, "训练记录"), (is_te, "^", 95, "测试记录（未见过）")]:
        k = (y == c) & mask
        if k.any():
            ax1.scatter(Y[k, 0], Y[k, 1], s=ms, c=COLORS[c], marker=mk,
                        edgecolors="white", linewidths=0.8, alpha=0.95,
                        label=f"{SEV[c]} %" if mk == "o" else None)
ax1.set_xticks([]); ax1.set_yticks([])
h, l = ax1.get_legend_handles_labels()
extra = [plt.Line2D([], [], marker="^", ls="", color="#555555", label="测试记录（未见过）")]
ax1.legend(handles=h + extra, labels=l + ["测试记录（未见过）"], fontsize=8, title="严重程度",
           title_fontsize=9, loc="best", framealpha=0.9)
ax1.set_title(f"t-SNE 记录级特征分布（84 条记录；测试集窗口准确率 "
              f"{m['window_test_acc']*100:.1f}%）", fontsize=11)
for s in ax1.spines.values():
    s.set_color("#cccccc")

cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
ax2.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
for i in range(7):
    for j in range(7):
        if cm[i, j]:
            ax2.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=8,
                     color="white" if cmn[i, j] > 0.5 else "#222")
ax2.set_xticks(range(7)); ax2.set_yticks(range(7))
ax2.set_xticklabels(SEV, rotation=45, ha="right", fontsize=8)
ax2.set_yticklabels(SEV, fontsize=8)
ax2.set_xlabel("预测（%）", fontsize=9); ax2.set_ylabel("真实（%）", fontsize=9)
ax2.set_title("测试切片混淆矩阵（未见过的整条记录）", fontsize=11)

fig.suptitle("物理特征 + 深度网络：三相电流匝间短路严重度识别（按工况归一化）", fontsize=13, y=0.98)
fig.tight_layout(rect=(0, 0, 1, 0.94))
fig.savefig("figs/a1_deep_tsne.png", dpi=200)
print("saved figs/a1_deep_tsne.png", m)
