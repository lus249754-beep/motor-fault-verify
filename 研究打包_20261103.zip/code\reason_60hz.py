"""Reasoning-style model: dimensionless physical features, whole-recording holdout.

Leave-one-load-out at 60 Hz: train on three loads, test on the fourth (unseen recordings).
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from deep_feat import physics_features

LABELS = [1, 2, 3, 4, 6, 7, 9]
torch.manual_seed(0)
np.random.seed(0)


class Net(nn.Module):
    def __init__(self, nf=27, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 64), nn.BatchNorm1d(64), nn.ReLU(), nn.Dropout(0.3),
                                  nn.Linear(64, 64), nn.BatchNorm1d(64), nn.ReLU())
        self.fc = nn.Linear(64, n_cls)

    def forward(self, x, feat=False):
        z = self.body(x)
        return z if feat else self.fc(z)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0)
    x, rec, load = x[m], rec[m], load[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    Fp = physics_features(x, speed[m])
    cond = load

    print(f"{'held-out load':>14s} {'train n':>8s} {'test n':>7s} {'window':>7s} {'record':>7s}")
    for held in sorted(set(np.round(cond, 2))):
        te = np.isclose(cond, held)
        tr = ~te
        Z = Fp.copy()
        for key in np.unique(cond):
            mm = np.isclose(cond, key)
            src = mm & tr if (mm & tr).sum() > 10 else mm      # unseen load: self-calibrate
            Z[mm] = (Fp[mm] - Fp[src].mean(0)) / (Fp[src].std(0) + 1e-6)
        Z = ((Z - Z[tr].mean(0)) / (Z[tr].std(0) + 1e-6)).astype(np.float32)

        X, Y = torch.from_numpy(Z), torch.from_numpy(np.array(y))
        net = Net()
        opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
        idx = np.flatnonzero(tr)
        for ep in range(200):
            net.train(); np.random.shuffle(idx)
            for b in range(0, len(idx), 64):
                s = idx[b:b + 64]
                loss = F.cross_entropy(net(X[s] + 0.05 * torch.randn_like(X[s])), Y[s])
                opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            p = net(X).argmax(1).numpy()
        wacc = float((p[te] == y[te]).mean())
        votes = {}
        for i in np.flatnonzero(te):
            votes.setdefault(rec[i], []).append(p[i])
        rc = sum(int(np.bincount(v, minlength=7).argmax() == y[np.flatnonzero(rec == r)[0]])
                 for r, v in votes.items())
        print(f"{held:14.2f} {tr.sum():8d} {te.sum():7d} {wacc:7.3f} {rc/len(votes):7.3f}"
              f"   ({rc}/{len(votes)} records)", flush=True)


if __name__ == "__main__":
    main()
