"""Two unseen severities at once: 12.30 % (between 4-6) and 37.30 % (between 7-9)."""
import json
import os

import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from deep_feat import physics_features
from reason_harm import extra_features
from accuracy_push import smooth
from openset_final import LABELS

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV = np.array([1.98, 3.97, 5.95, 8.33, 20.64, 28.97, 45.63])
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]
BANDS = {12.30: (8.33, 20.64, "第 5 档"), 37.30: (28.97, 45.63, "第 8 档")}


class Reg(nn.Module):
    def __init__(self, nf):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(0.2),
                                  nn.Linear(128, 128), nn.BatchNorm1d(128), nn.ReLU())
        self.out = nn.Linear(128, 1)

    def forward(self, x):
        return self.out(self.body(x)).squeeze(1)


def load_unseen(sev_text):
    f = f"a1_slices/60-0.07-1-A-{sev_text}-slices.mat"
    X = np.asarray(sio.loadmat(f)["X"], dtype=np.float32)
    w = np.stack([resample(X[:, :, k], 1500, axis=0).T for k in range(X.shape[2])]).astype(np.float32)
    s = np.full(len(w), 60.0)
    return np.concatenate([physics_features(w, s), extra_features(w, s)], 1)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    Feat = np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1)
    Fs = smooth(Feat, y)
    U = {12.30: load_unseen("12.30"), 37.30: load_unseen("37.30")}
    Us = {k: smooth(v, np.zeros(len(v), int)) for k, v in U.items()}

    # ---------------- stage 1: raw-feature Mahalanobis
    mu, sd = Feat[tr].mean(0), Feat[tr].std(0) + 1e-6
    Z, Zs = (Feat - mu) / sd, (Fs - mu) / sd
    proto = np.stack([Z[tr & (y == c)].mean(0) for c in range(7)])
    icov = np.linalg.inv(np.cov((Z[tr] - proto[y[tr]]).T) + 1e-3 * np.eye(Z.shape[1]))

    def dm(A):
        return np.stack([np.einsum("ij,jk,ik->i", A - proto[c], icov, A - proto[c])
                         for c in range(7)]).min(0)

    thr = float(np.quantile(dm(Z[va]), 0.99))
    ka = float((dm(Z[te]) < thr).mean())
    rej = {k: float((dm((v - mu) / sd) >= thr).mean()) for k, v in U.items()}

    # ---------------- stage 2: dedicated severity regressor
    tgt = torch.from_numpy(np.log(SEV)[y].astype(np.float32))
    Zt = torch.from_numpy(Zs.astype(np.float32))
    pred_k, pred_u = [], {12.30: [], 37.30: []}
    for seed in range(8):
        torch.manual_seed(seed); np.random.seed(seed)
        net = Reg(Zs.shape[1])
        opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
        idx = np.flatnonzero(tr)
        for ep in range(400):
            net.train(); np.random.shuffle(idx)
            for b in range(0, len(idx), 64):
                s = idx[b:b + 64]
                loss = F.mse_loss(net(Zt[s] + 0.03 * torch.randn_like(Zt[s])), tgt[s])
                opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            pred_k.append(np.exp(net(Zt).numpy()))
            for k, v in Us.items():
                pred_u[k].append(np.exp(net(torch.from_numpy(((v - mu) / sd).astype(np.float32))).numpy()))
    rk = np.mean(pred_k, 0)
    ru = {k: np.mean(v, 0) for k, v in pred_u.items()}

    mae = float(np.mean(np.abs(rk[te] - SEV[y[te]])))
    res = {"threshold": thr, "known_accept": ka, "severity_mae": mae}
    print(f"stage1: known accept {ka:.3f} | reject 12.30 {rej[12.30]:.3f} | reject 37.30 {rej[37.30]:.3f}")
    print(f"stage2: known MAE {mae:.2f}")
    for k, (lo, hi, name) in BANDS.items():
        med = float(np.median(ru[k]))
        band = float(((ru[k] > lo) & (ru[k] < hi)).mean())
        res[f"unseen_{k}"] = {"reject": rej[k], "median_pred": med, "in_band": band, "band_name": name}
        print(f"  {k:.2f} %: median {med:.2f} % | in ({lo}, {hi}) = {band:.3f} -> {name}")
    json.dump(res, open("a1_two_unseen.json", "w"), indent=2)

    # ---------------- figure
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.6, 5.8), gridspec_kw={"width_ratios": [1.25, 1]})
    rng = np.random.RandomState(0)
    for c in range(7):
        v = Feat[y == c, 0][te[y == c]]
        a1.scatter(SEV[c] + rng.uniform(-0.55, 0.55, len(v)), v, s=24, c=COLORS[c], alpha=0.8,
                   linewidths=0, label=f"{SEV_TXT[c]} %")
    for k, col in [(12.30, "#B22222"), (37.30, "#8B4513")]:
        a1.scatter(np.full(len(U[k]), k) + rng.uniform(-0.5, 0.5, len(U[k])), U[k][:, 0], s=28,
                   marker="x", c=col, linewidths=1.0, alpha=0.9, label=f"{k:.2f} %（未训练）")
    a1.set_yscale("log"); a1.set_xscale("log")
    a1.set_xticks(list(SEV) + [12.30, 37.30])
    a1.set_xticklabels(SEV_TXT + ["12.30", "37.30"], rotation=45, ha="right", fontsize=8)
    a1.set_xlabel("严重度（%）"); a1.set_ylabel("负序比 I2/I1")
    a1.set_title("两个未见档位都落在已知档之间", fontsize=11)
    a1.legend(fontsize=7, ncol=2)
    a1.grid(alpha=0.25, which="both")

    bins = np.linspace(5, 50, 46)
    a2.hist(rk[te], bins=bins, color="#4C72B0", alpha=0.55, label="已知（测试）")
    a2.hist(ru[12.30], bins=bins, color="#B22222", alpha=0.85, label="未见 12.30 %")
    a2.hist(ru[37.30], bins=bins, color="#8B4513", alpha=0.85, label="未见 37.30 %")
    for k, (lo, hi, name) in BANDS.items():
        a2.axvspan(lo, hi, alpha=0.10)
        a2.axvline(lo, ls="--", lw=0.9); a2.axvline(hi, ls="--", lw=0.9)
    a2.set_xscale("log")
    a2.set_xlabel("回归预测的严重度（%，对数轴）"); a2.set_ylabel("切片数")
    a2.set_title("第二级：12.30 % → 第 5 档，37.30 % → 第 8 档", fontsize=10.5)
    a2.legend(fontsize=8)
    fig.suptitle("同时输入两个未见档位：开集拒绝 + 区间定位（60 Hz / 0.07 N·m）", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig("figs/a1_two_unseen.png", dpi=190)
    print("saved")


if __name__ == "__main__":
    main()
