"""Scan the E: drive DL850 motor records (Health / A0.01 / A1 / A10)."""
import os
import re
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mat5 import Mat5

NAME_RE = re.compile(r"^(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)-(A|Health)-(\d+(?:\.\d+)?)-FOC\.(MAT|mat)$")


def census(path):
    m = Mat5(path)
    pos = 128
    out = []
    while pos < m.size - 8:
        t = m.tag(pos)
        if t is None or not (1 <= t[0] <= 30):
            break
        typ, size, dpos, end = t
        if typ == 14:
            name, val = m.matrix(pos)
            shape = getattr(val, "shape", None)
            dt = getattr(val, "dtype", None)
            out.append((name, shape, str(dt)))
        pos = m._advance(pos, dpos, size)
    m.close()
    return out


def main():
    root = sys.argv[1]
    files = sorted(f for f in os.listdir(root) if f.lower().endswith(".mat"))
    print(f"### {root}  ({len(files)} MAT files, {sum(os.path.getsize(os.path.join(root, f)) for f in files)/1e9:.2f} GB)")
    meta = []
    for f in files:
        mm = NAME_RE.match(f)
        meta.append((f, mm.groups() if mm else None))
    bad = [f for f, g in meta if g is None]
    if bad:
        print("  unparsable names:", bad)
    speeds = sorted({float(g[0]) for _, g in meta if g})
    loads = sorted({float(g[1]) for _, g in meta if g})
    rfs = sorted({float(g[2]) for _, g in meta if g})
    states = sorted({g[3] for _, g in meta if g})
    grades = sorted({float(g[4]) for _, g in meta if g})
    print("  speeds[Hz] =", speeds)
    print("  loads[Nm]  =", loads)
    print("  Rf[ohm]    =", rfs)
    print("  states     =", states)
    print("  grades[%]  =", grades)
    sizes = sorted({os.path.getsize(os.path.join(root, f)) for f in files})
    print("  file sizes =", [f"{s/1e6:.1f} MB" for s in sizes])
    for f in files[:6]:
        print("   ", f)
    if len(files) > 6:
        print(f"    ... (+{len(files)-6} more)")
    probe = files[0]
    print(f"  --- variables in {probe} ---")
    for name, shape, dt in census(os.path.join(root, probe)):
        print(f"    {name:10s} {str(shape):18s} {dt}")


if __name__ == "__main__":
    main()
