"""CNN on the 7-class A1 slice set: 3-phase currents -> severity class.

Only a1_slices_7cls is used. Windows are decimated 100x (1 MHz -> 10 kHz,
1500 points) with FFT resampling, then a small 1D CNN is trained.
Outputs: metrics.json, confusion matrix, and a t-SNE map of the features.
"""
import csv
import json
import os
import time

import numpy as np
import torch
import torch.nn as nn
from scipy.io import loadmat
from scipy.signal import resample

DATA = "a1_slices_7cls"
CACHE = "a1_7cls_10k.npz"
SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)


# --------------------------------------------------------------------------- data
def build_cache():
    rows = list(csv.DictReader(open(os.path.join(DATA, "slice_index.csv"), encoding="utf-8-sig")))
    by_file = {}
    for r in rows:
        by_file.setdefault(r["file"], []).append(r)
    Xs, ys, sp, rec, speed, load = [], [], [], [], [], []
    t0 = time.time()
    for i, (fname, rs) in enumerate(sorted(by_file.items()), 1):
        d = loadmat(os.path.join(DATA, fname))
        X = np.asarray(d["X"], dtype=np.float32)              # (150000, 3, nWin)
        nw = X.shape[2]
        x = X.transpose(1, 2, 0).reshape(3 * nw, -1).T        # (150000, 3*nWin)
        y = np.asarray(resample(x, 1500, axis=0), dtype=np.float32)   # 1 MHz -> 10 kHz
        y = y.reshape(1500, 3, nw)                            # (1500, 3, nWin)
        Xs.append(y.transpose(2, 1, 0).copy())                # (nWin, 3, 1500)
        meta = rs[0]
        ys.append(np.full(nw, int(meta["label"]), dtype=np.int64))
        sp.extend([r["split"] for r in rs])
        rec.extend([meta["record"]] * nw)
        speed.append(np.full(nw, float(meta["speed"]), dtype=np.float32))
        load.append(np.full(nw, float(meta["load"]), dtype=np.float32))
        if i % 12 == 0:
            print(f"  cache {i}/{len(by_file)}  {time.time()-t0:.0f}s", flush=True)
    np.savez_compressed(CACHE, X=np.concatenate(Xs), y=np.concatenate(ys),
                        split=np.array(sp), record=np.array(rec),
                        speed=np.concatenate(speed), load=np.concatenate(load))
    print("cache saved", CACHE, np.concatenate(Xs).shape, f"{time.time()-t0:.0f}s")


def load_cache():
    if not os.path.exists(CACHE):
        build_cache()
    d = np.load(CACHE, allow_pickle=True)
    return d["X"], d["y"], d["split"], d["record"], d["speed"], d["load"]


# --------------------------------------------------------------------------- model
class CNN(nn.Module):
    def __init__(self, n_cls=7, ch=24):
        super().__init__()
        def blk(i, o, k):
            return [nn.Conv1d(i, o, k, stride=2, padding=k // 2), nn.BatchNorm1d(o), nn.ReLU(inplace=True)]
        self.body = nn.Sequential(*blk(3, ch, 11), *blk(ch, ch * 2, 7),
                                  *blk(ch * 2, ch * 4, 5), *blk(ch * 4, ch * 4, 5))
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.drop = nn.Dropout(0.2)
        self.fc = nn.Linear(ch * 4, n_cls)

    def forward(self, x, feat=False):
        h = self.body(x)
        z = self.pool(h).flatten(1)
        if feat:
            return z
        return self.fc(self.drop(z))


def augment(xb):
    b = xb.shape[0]
    gain = torch.empty(b, 1, 1).uniform_(0.80, 1.25)          # load / amplitude jitter
    chan = torch.empty(b, 3, 1).uniform_(0.97, 1.03)          # small channel gain mismatch
    xb = xb * gain * chan
    sh = int(torch.randint(-400, 401, (1,)))
    xb = torch.roll(xb, sh, dims=2)                           # phase shift invariance
    return xb + 0.03 * torch.randn_like(xb)


def train(x, y, tr, va, te, epochs=60, bs=128, lr=2e-3):
    dev = "cpu"
    model = CNN().to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=5e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    lossf = nn.CrossEntropyLoss(label_smoothing=0.03)
    xt = torch.from_numpy(x)
    yt = torch.from_numpy(y)
    idx = np.flatnonzero(tr)
    best, best_state, hist = -1, None, []
    for ep in range(epochs):
        model.train()
        np.random.shuffle(idx)
        tot, correct = 0, 0
        for b in range(0, len(idx), bs):
            sel = idx[b:b + bs]
            xb, yb = augment(xt[sel]), yt[sel]
            opt.zero_grad()
            out = model(xb)
            loss = lossf(out, yb)
            loss.backward()
            opt.step()
            tot += len(sel)
            correct += (out.argmax(1) == yb).sum().item()
        sched.step()
        model.eval()
        with torch.no_grad():
            pv = model(xt[va]).argmax(1).numpy()
        vacc = float((pv == y[va]).mean())
        hist.append({"epoch": ep + 1, "train_acc": correct / tot, "val_acc": vacc})
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in model.state_dict().items()}
        if (ep + 1) % 10 == 0:
            print(f"  ep{ep+1:3d} train {correct/tot:.4f} val {vacc:.4f}", flush=True)
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        pt = model(xt[te]).argmax(1).numpy()
    return model, float((pt == y[te]).mean()), hist


# --------------------------------------------------------------------------- tsne
def tsne(X, perplexity=30.0, iters=800, lr=180.0):
    X = torch.tensor(X, dtype=torch.float32)
    X = X - X.mean(0)
    X = X / X.std(0).clamp_min(1e-8)
    n = X.shape[0]
    d2 = torch.cdist(X, X) ** 2
    # binary search for sigma per point
    P = torch.zeros(n, n)
    target = np.log(perplexity)
    for i in range(n):
        d = d2[i].clone()
        d[i] = 1e9
        beta, lo, hi = 1.0, 1e-20, 1e20
        for _ in range(60):
            p = torch.exp(-d * beta)
            p = p / p.sum()
            ent = -(p * torch.log(p + 1e-12)).sum()
            if ent > target:
                hi = beta
                beta = (beta + lo) / 2
            else:
                lo = beta
                beta = (beta + hi) / 2 if hi < 1e19 else beta * 2
        P[i] = torch.exp(-d * beta)
        P[i, i] = 0
    P = P / P.sum()
    P = (P + P.t()) / 2
    P = P / P.sum()
    Y = torch.randn(n, 2) * 1e-4
    vel = torch.zeros_like(Y)
    for it in range(iters):
        exag = 12.0 if it < 250 else 1.0
        num = 1.0 / (1.0 + torch.cdist(Y, Y) ** 2)
        num.fill_diagonal_(0)
        Q = num / num.sum()
        PQ = (exag * P - Q) * num
        grad = 4 * (PQ.sum(1, keepdim=True) * Y - PQ @ Y)
        vel = 0.9 * vel - lr * grad
        Y = Y + vel
        Y = Y - Y.mean(0)
        if (it + 1) % 200 == 0:
            print(f"  tsne {it+1}/{iters}", flush=True)
    return Y.numpy()


# --------------------------------------------------------------------------- main
def main():
    t0 = time.time()
    x, y, _sp, rec, speed, load = load_cache()
    # keep only the 7 classes present in a1_slices_7cls, remapped to 0..6
    LABELS = [1, 2, 3, 4, 6, 7, 9]
    remap = {v: i for i, v in enumerate(LABELS)}
    y = np.array([remap[int(v)] for v in y], dtype=np.int64)

    # split: "time" = held-out slices from every record (60/20/20 with guard bands,
    # already encoded in the slice file); "record" = whole recordings never seen.
    mode = os.environ.get("A1_SPLIT", "time")
    if mode == "record":
        rng = np.random.RandomState(0)
        tr = np.zeros(len(y), bool)
        va = np.zeros(len(y), bool)
        te = np.zeros(len(y), bool)
        for c in range(7):
            recs = sorted(set(rec[y == c]))
            rng.shuffle(recs)
            te |= np.isin(rec, recs[:2])
            va |= np.isin(rec, recs[2:3])
            tr |= np.isin(rec, recs[3:])
    else:
        tr, va, te = _sp == "train", _sp == "val", _sp == "test"
    print("split sizes", int(tr.sum()), int(va.sum()), int(te.sum()), flush=True)
    print("train conditions", sorted({(round(float(s), 1), round(float(l), 2))
                                      for s, l in zip(speed[tr], load[tr])}), flush=True)
    print("test  conditions", sorted({(round(float(s), 1), round(float(l), 2))
                                      for s, l in zip(speed[te], load[te])}), flush=True)
    print("records per class: train",
          {c: len({r for r in rec[tr][y[tr] == c]}) for c in range(7)},
          "test", {c: len({r for r in rec[te][y[te] == c]}) for c in range(7)}, flush=True)

    # per-window conditioning only for the cross-recording test: remove DC and
    # normalise by the mean phase RMS so absolute load amplitude cannot dominate,
    # while inter-phase imbalance is kept.
    if mode == "record":
        x = x - x.mean(axis=2, keepdims=True)
        rms = np.sqrt((x ** 2).mean(axis=2, keepdims=True))
        x = (x / (rms.mean(axis=1, keepdims=True) + 1e-9)).astype(np.float32)

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    model, test_acc, hist = train(x, y, tr, va, te, epochs=120)
    xt = torch.from_numpy(x[te])
    with torch.no_grad():
        logit = sum(torch.log_softmax(model(torch.roll(xt, s, dims=2)), 1)
                    for s in (0, -60, 60, -120, 120)) / 5.0
        pred = logit.argmax(1).numpy()
    test_acc = float((pred == y[te]).mean())
    cm = np.zeros((7, 7), dtype=int)
    for t, p in zip(y[te], pred):
        cm[t, p] += 1
    per_cls = cm.diagonal() / np.maximum(cm.sum(1), 1)
    print("test acc", test_acc)
    print(cm)

    with torch.no_grad():
        feat = model(torch.from_numpy(x[te]), feat=True).numpy()
    Y = tsne(feat, iters=600)
    np.savez("a1_7cls_tsne.npz", Y=Y, y=y[te], speed=speed[te], load=load[te], record=rec[te],
             feat=feat, hist=np.array([(h["train_acc"], h["val_acc"]) for h in hist]),
             cm=cm, test_acc=test_acc)
    json.dump({"test_acc": float(test_acc), "per_class": per_cls.tolist(), "labels": LABELS,
               "n_train": int(tr.sum()), "n_val": int(va.sum()), "n_test": int(te.sum()),
               "heldout": "load 34.14 N.m (all speeds), never seen in training",
               "history": hist}, open("a1_7cls_metrics.json", "w"), indent=1)
    print(f"done {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
