"""Load A1 slices produced by slice_a1.py.

    from a1_slices import iter_slices, record_list
    for X, y, meta in iter_slices("a1_slices", split="train", speed=20):
        ...
"""
import csv
import os

import numpy as np

INDEX = "slice_index.csv"


def record_list(out_dir):
    """One dict per source record, with split counts."""
    rows = list(csv.DictReader(open(os.path.join(out_dir, INDEX), encoding="utf-8-sig")))
    recs = {}
    for r in rows:
        recs.setdefault(r["file"], {"file": r["file"], "record": r["record"],
                                    "label": int(r["label"]), "severity": float(r["severity"]),
                                    "speed": float(r["speed"]), "load": float(r["load"]),
                                    "resistance": float(r["resistance"]), "n": 0})
        recs[r["file"]]["n"] += 1
    return sorted(recs.values(), key=lambda d: (d["speed"], d["load"], d["label"]))


def load_file(path, split=None, dtype=np.float32):
    import scipy.io as sio
    d = sio.loadmat(path)
    X = np.asarray(d["X"], dtype=dtype)
    y = np.asarray(d["Y"]).ravel().astype(np.int64)
    sp = np.array([str(np.ravel(s)[0]) if isinstance(s, np.ndarray) else str(s)
                   for s in np.asarray(d["split"]).ravel()])
    meta = {"sourceFile": str(d["sourceFile"].ravel()[0]), "speed": float(d["speed"].ravel()[0]),
            "load": float(d["load"].ravel()[0]), "resistance": float(d["resistance"].ravel()[0]),
            "severity": float(d["severity"].ravel()[0]),
            "sourceStart": np.asarray(d["sourceStart"]).ravel().astype(np.int64)}
    if split is not None:
        k = sp == split
        X, y, meta["sourceStart"] = X[:, :, k], y[k], meta["sourceStart"][k]
    return X, y, meta


def iter_slices(out_dir, split=None, speed=None, load=None, label=None, chunk=8):
    """Yield (X, y, meta) chunks; X is (window, 3, n) float32."""
    recs = record_list(out_dir)
    for r in recs:
        if speed is not None and r["speed"] != speed:
            continue
        if load is not None and r["load"] != load:
            continue
        if label is not None and r["label"] != label:
            continue
        X, y, meta = load_file(os.path.join(out_dir, r["file"]), split=split)
        if X.shape[2] == 0:
            continue
        meta["label"] = r["label"]
        yield X, y, meta
