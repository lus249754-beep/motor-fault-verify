"""Longer effective window: average the physical features over 5 consecutive slices."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from deep_feat import physics_features
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]
GROUP = 5
torch.manual_seed(0)
np.random.seed(0)


class Net(nn.Module):
    def __init__(self, nf=27, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 64), nn.BatchNorm1d(64), nn.ReLU(),
                                  nn.Linear(64, 64), nn.BatchNorm1d(64), nn.ReLU())
        self.proj = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 16))
        self.fc = nn.Linear(64, n_cls)

    def forward(self, x):
        z = self.body(x)
        return z, self.proj(z), self.fc(z)


def supcon(z, y, t=0.1):
    z = F.normalize(z, 1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    Fp = physics_features(x, speed[m])

    # average features over consecutive slices, class by class (time order preserved)
    Xs, ys, phase = [], [], []
    for c in range(7):
        idx = np.flatnonzero(y == c)
        ngrp = len(idx) // GROUP
        for g in range(ngrp):
            sel = idx[g * GROUP:(g + 1) * GROUP]
            Xs.append(Fp[sel].mean(0))
            ys.append(c)
            phase.append(g / max(ngrp - 1, 1))
    Xf = np.stack(Xs).astype(np.float32)
    yy = np.array(ys)
    ph = np.array(phase)
    tr, va, te = ph < 0.6, (ph >= 0.6) & (ph < 0.8), ph >= 0.8
    print("averaged samples", Xf.shape, "train/val/test", tr.sum(), va.sum(), te.sum())
    Z = ((Xf - Xf[tr].mean(0)) / (Xf[tr].std(0) + 1e-6)).astype(np.float32)

    X, Y = torch.from_numpy(Z), torch.from_numpy(yy)
    net = Net()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(300):
        net.train(); np.random.shuffle(idx)
        for b in range(0, len(idx), 32):
            s = idx[b:b + 32]
            xb = X[s] + 0.03 * torch.randn_like(X[s])
            z, p, out = net(xb)
            loss = F.cross_entropy(out, Y[s]) + 0.5 * supcon(p, Y[s])
            opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            vacc = float((net(X[va])[2].argmax(1).numpy() == yy[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        pred = net(X)[2].argmax(1).numpy()
        emb = net(X)[1].numpy()
    acc = float((pred[te] == yy[te]).mean())
    print(f"test acc {acc:.3f}")

    cm = np.zeros((7, 7), int)
    for t, p in zip(yy[te], pred[te]):
        cm[t, p] += 1
    E = emb[te] / (np.linalg.norm(emb[te], axis=1, keepdims=True) + 1e-9)
    Yt = tsne(E, perplexity=10, iters=1500)

    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5.4), gridspec_kw={"width_ratios": [1.35, 1]})
    for k in range(7):
        a1.scatter(Yt[yy[te] == k, 0], Yt[yy[te] == k, 1], s=52, c=COLORS[k], alpha=0.92,
                   linewidths=0, label=SEV_TXT[k] + " %")
    a1.set_xticks([]); a1.set_yticks([])
    a1.legend(fontsize=8, title="严重程度", title_fontsize=9)
    a1.set_title(f"0.25 s 有效窗的判别嵌入 t-SNE（测试 n={int(te.sum())} 段）", fontsize=10.5)
    a2.imshow(cm / np.maximum(cm.sum(1, keepdims=True), 1), cmap="Blues", vmin=0, vmax=1)
    for i in range(7):
        for j in range(7):
            if cm[i, j]:
                a2.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=9,
                        color="white" if cm[i, j] / max(cm[i].sum(), 1) > 0.5 else "#222")
    a2.set_xticks(range(7)); a2.set_yticks(range(7))
    a2.set_xticklabels(SEV_TXT, rotation=45, ha="right", fontsize=8)
    a2.set_yticklabels(SEV_TXT, fontsize=8)
    a2.set_xlabel("预测（%）"); a2.set_ylabel("真实（%）")
    a2.set_title(f"混淆矩阵（准确率 {acc*100:.1f}%）", fontsize=10.5)
    fig.suptitle("60 Hz / 0.07 N·m：物理量在 5 个切片上平均后的判别嵌入", fontsize=12.5, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig("figs/a1_reason_avg.png", dpi=190)
    json.dump({"acc": acc, "n_test": int(te.sum())}, open("a1_reason_avg.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
