"""Final t-SNE: known 7 + unseen 12.30 %, with the unseen group drawn as a hull."""
import numpy as np
import scipy.io as sio
import torch
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from scipy.signal import resample

from stage2_60hz_007 import CNN, LABELS
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]


def hull(points):
    pts = points[np.argsort(np.arctan2(points[:, 1] - points[:, 1].mean(),
                                      points[:, 0] - points[:, 0].mean()))]
    return pts


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp, y0 = x[m], sp[m], y0[m]
    y = np.array([LABELS.index(int(v)) for v in y0])
    tr, te = sp == "train", sp == "test"
    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)
    X = np.asarray(sio.loadmat("a1_slices/60-0.07-1-A-12.30-slices.mat")["X"], dtype=np.float32)
    m3, s3 = mu.reshape(3, 1), sd.reshape(3, 1)
    xu = np.stack([((resample(X[:, :, k], 1500, axis=0).T - m3) / s3).astype(np.float32)
                   for k in range(X.shape[2])])

    net = CNN()
    net.load_state_dict(torch.load("a1_2stage_60hz_007.pt", map_location="cpu"))
    net.eval()
    with torch.no_grad():
        fte = net(torch.from_numpy(x[te]))[0].numpy()
        fuk = net(torch.from_numpy(xu))[0].numpy()
    nk = len(fte)
    E = np.concatenate([fte, fuk])
    E = E / (np.linalg.norm(E, axis=1, keepdims=True) + 1e-9)
    Y = tsne(E, perplexity=15, iters=1500)

    fig, ax = plt.subplots(figsize=(9.6, 7.0))
    for c in range(7):
        mm = y[te] == c
        ax.scatter(Y[:nk][mm, 0], Y[:nk][mm, 1], s=60, c=COLORS[c], alpha=0.95,
                   edgecolors="white", linewidths=0.6, label=f"{SEV_TXT[c]} %（第{LABELS[c]}档）")
    U = Y[nk:]
    h = hull(U)
    ax.add_patch(Polygon(h, closed=True, facecolor="#B22222", alpha=0.18,
                         edgecolor="#B22222", linewidth=1.0))
    ax.scatter(U[:, 0], U[:, 1], s=14, marker="x", c="#B22222", linewidths=0.9,
               alpha=0.9, label="12.30 %（未训练，86 切片）")
    ax.set_xticks([]); ax.set_yticks([])
    ax.legend(fontsize=8.5, loc="best", framealpha=0.9, title="严重度")
    ax.set_title("60 Hz / 0.07 N·m：7 个已知档与未见的 12.30 %\n"
                 "未见组类内平均余弦距离 1×10⁻⁴（与已知类同量级），红色包络为 86 个切片的位置",
                 fontsize=10.5)
    for s in ax.spines.values():
        s.set_color("#cccccc")
    fig.tight_layout()
    fig.savefig("figs/a1_2stage_tsne_hull.png", dpi=200)
    print("saved")


if __name__ == "__main__":
    main()
