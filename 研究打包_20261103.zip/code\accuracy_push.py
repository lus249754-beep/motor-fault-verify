"""Accuracy push: temporal smoothing of features + 5-model ensemble."""
import json

import numpy as np
import torch
import torch.nn.functional as F

from deep_feat import physics_features
from reason_harm import extra_features, supcon, Net

LABELS = [1, 2, 3, 4, 6, 7, 9]


def smooth(F, y, k=3):
    """average features over k consecutive slices inside each class block"""
    out = F.copy()
    for c in range(7):
        idx = np.flatnonzero(y == c)
        for j, i in enumerate(idx):
            lo, hi = max(0, j - k // 2), min(len(idx), j + k // 2 + 1)
            out[i] = F[idx[lo:hi]].mean(0)
    return out


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    te = sp == "test"
    fit = ~te

    Fp = np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1)
    res = {}
    for tag, Fuse in [("raw", Fp), ("smoothed-3", smooth(Fp, y))]:
        Z = ((Fuse - Fuse[fit].mean(0)) / (Fuse[fit].std(0) + 1e-6)).astype(np.float32)
        X, Y = torch.from_numpy(Z), torch.from_numpy(y)
        probs, accs = [], []
        for seed in range(5):
            torch.manual_seed(seed)
            np.random.seed(seed)
            net = Net(Z.shape[1])
            opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
            idx = np.flatnonzero(fit)
            for ep in range(300):
                net.train(); np.random.shuffle(idx)
                for b in range(0, len(idx), 64):
                    s = idx[b:b + 64]
                    xb = X[s] + 0.05 * torch.randn_like(X[s])
                    z, p, out = net(xb)
                    loss = F.cross_entropy(out, Y[s]) + 0.8 * supcon(p, Y[s])
                    opt.zero_grad(); loss.backward(); opt.step()
            net.eval()
            with torch.no_grad():
                logit = net(X)[2]
                pr = F.softmax(logit, 1).numpy()
            probs.append(pr)
            accs.append(float((pr[te].argmax(1) == y[te]).mean()))
        ens = np.mean(probs, 0)
        ens_acc = float((ens[te].argmax(1) == y[te]).mean())
        res[tag] = {"single_mean": float(np.mean(accs)), "single_best": float(np.max(accs)),
                    "ensemble": ens_acc, "n_errors": int((ens[te].argmax(1) != y[te]).sum())}
        print(f"{tag:12s} single avg {np.mean(accs):.3f}  best {np.max(accs):.3f}  "
              f"ensemble {ens_acc:.3f}  errors {(ens[te].argmax(1) != y[te]).sum()}/98", flush=True)

    json.dump(res, open("a1_accuracy_push.json", "w"), indent=1)


if __name__ == "__main__":
    main()
