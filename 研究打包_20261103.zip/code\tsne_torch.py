"""Exact t-SNE (torch, CPU) -- correct beta search and gain/momentum updates."""
import numpy as np
import torch


def tsne(X, perplexity=30.0, iters=1000, lr=200.0, seed=0):
    torch.manual_seed(seed)
    X = torch.tensor(np.asarray(X), dtype=torch.float32)
    X = X - X.mean(0)
    X = X / X.std(0).clamp_min(1e-8)
    n = X.shape[0]
    d2 = torch.cdist(X, X) ** 2
    target = float(np.log(perplexity))
    P = torch.zeros(n, n)
    for i in range(n):
        d = d2[i].clone()
        d[i] = 1e18
        beta = 1.0
        lo, hi = 1e-20, 1e20
        for _ in range(80):
            p = torch.exp(-d * beta)
            p = p / p.sum().clamp_min(1e-12)
            ent = -(p * torch.log(p.clamp_min(1e-12))).sum()
            diff = float(ent - target)
            if diff > 0:            # too flat -> sharpen
                lo = beta
                beta = (beta + hi) / 2 if hi < 1e19 else beta * 2
            else:                   # too peaky -> flatten
                hi = beta
                beta = (beta + lo) / 2
            if abs(diff) < 1e-6:
                break
        P[i] = p
    P = (P + P.t()) / 2
    P = P / P.sum()

    Y = torch.randn(n, 2) * 1e-4
    vel = torch.zeros_like(Y)
    gains = torch.ones_like(Y)
    for it in range(iters):
        P_use = P * 12.0 if it < 250 else P
        mom = 0.5 if it < 250 else 0.8
        num = 1.0 / (1.0 + torch.cdist(Y, Y) ** 2)
        num.fill_diagonal_(0)
        Q = num / num.sum().clamp_min(1e-12)
        PQ = (P_use - Q) * num
        grad = 4.0 * (PQ.sum(1, keepdim=True) * Y - PQ @ Y)
        same = (grad * vel) < 0
        gains = torch.where(same, gains * 0.8, gains + 0.2).clamp(0.01, 10.0)
        vel = mom * vel - lr * gains * grad
        Y = Y + vel
        Y = Y - Y.mean(0)
        if (it + 1) % 200 == 0:
            print(f"  tsne {it+1}/{iters}", flush=True)
    return Y.numpy()
