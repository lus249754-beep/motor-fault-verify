"""Physics-informed deep model for A1 severity: CNN + sequence features, condition normalised.

Inputs  : 3-phase current window (1500 pts @ 10 kHz) + 27 physics features
          (I2/I1, I0/I1, per-phase amplitude ratios, harmonics 2/3/5/7/9/11, THD).
Model   : 1D-CNN branch + MLP branch -> 128-d embedding -> 7 classes.
Loss    : cross-entropy + supervised contrastive (keeps the feature space clustered).
Split   : 9 records/class train, 1 val, 2 test -- test recordings never seen.
"""
import json
import os

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from tsne_torch import tsne

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
FS = 10000.0
torch.manual_seed(0)
np.random.seed(0)


# ------------------------------------------------------------------ features
def physics_features(x, speed):
    n, _, N = x.shape
    w = np.hanning(N).astype(np.float32)
    spec = np.fft.rfft(x * w, axis=2)
    a = np.exp(2j * np.pi / 3)
    out = np.zeros((n, 27), np.float32)
    for i in range(n):
        k1 = max(1, int(round(speed[i] / (FS / N))))
        ph = spec[i, :, k1]
        amp = np.abs(ph)
        m = amp.mean() + 1e-9
        I1 = (ph[0] + a * ph[1] + a * a * ph[2]) / 3
        I2 = (ph[0] + a * a * ph[1] + a * ph[2]) / 3
        I0 = ph.sum() / 3
        f = [abs(I2) / (abs(I1) + 1e-9), abs(I0) / (abs(I1) + 1e-9), abs(I1) / m]
        f += list(amp / m)
        for h in (2, 3, 5, 7, 9, 11):
            f += list(np.abs(spec[i, :, h * k1]) / (amp + 1e-9))
        for c in range(3):
            band = np.abs(spec[i, c, k1 + 1:])
            f.append(float(np.sqrt((band ** 2).sum()) / (amp[c] + 1e-9)))
        out[i] = f
    return out


def condition_norm(F, cond, tr):
    Z = F.copy()
    for key in np.unique(cond, axis=0):
        m = np.all(cond == key, axis=1)
        mu, sd = F[m & tr].mean(0), F[m & tr].std(0) + 1e-6
        Z[m] = (F[m] - mu) / sd
    return Z


# ------------------------------------------------------------------ model
class Net(nn.Module):
    def __init__(self, nfeat=27, n_cls=7):
        super().__init__()
        def blk(i, o, k):
            return [nn.Conv1d(i, o, k, 2, k // 2), nn.BatchNorm1d(o), nn.ReLU(inplace=True)]
        self.cnn = nn.Sequential(*blk(3, 24, 11), *blk(24, 48, 7), *blk(48, 96, 5))
        self.fmlp = nn.Sequential(nn.Linear(nfeat, 64), nn.BatchNorm1d(64), nn.ReLU(),
                                  nn.Linear(64, 64), nn.ReLU())
        self.emb = nn.Sequential(nn.Linear(96 + 64, 128), nn.BatchNorm1d(128), nn.ReLU())
        self.fc = nn.Linear(128, n_cls)

    def forward(self, x, f, feat=False):
        h = self.cnn(x).mean(2)
        z = self.emb(torch.cat([h, self.fmlp(f)], 1))
        if feat:
            return z
        return self.fc(z)


def supcon(z, y, t=0.1):
    z = F.normalize(z, dim=1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def augment(xb, fb):
    b = xb.shape[0]
    g = torch.empty(b, 1, 1).uniform_(0.85, 1.18)
    s = int(torch.randint(-250, 251, (1,)))
    xb = torch.roll(xb * g, s, dims=2) + 0.02 * torch.randn_like(xb)
    fb = fb + 0.05 * torch.randn_like(fb)
    return xb, fb


# ------------------------------------------------------------------ main
def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
    y = np.array([LABELS.index(int(v)) for v in y0])
    cond = np.stack([speed, load], 1)

    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        recs = sorted(set(rec[y == c]))
        rng.shuffle(recs)
        te |= np.isin(rec, recs[:2])
        va |= np.isin(rec, recs[2:3])
        tr |= np.isin(rec, recs[3:])
    print("windows train/val/test", tr.sum(), va.sum(), te.sum(), flush=True)

    Fp = physics_features(x, speed)
    Fp = condition_norm(Fp, cond, tr)
    Fp = ((Fp - Fp[tr].mean(0)) / (Fp[tr].std(0) + 1e-6)).astype(np.float32)

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    xs = ((x - mu) / sd).astype(np.float32)

    Xt = torch.from_numpy(xs); Ft = torch.from_numpy(Fp); yt = torch.from_numpy(y)
    net = Net()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    epochs, bs = 40, 128
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), bs):
            sel = idx[b:b + bs]
            xb, fb = augment(Xt[sel], Ft[sel])
            yb = yt[sel]
            z = net(xb, fb, feat=True)
            out = net.fc(z)
            loss = F.cross_entropy(out, yb) + 0.5 * supcon(z, yb)
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == yb).sum().item(); tot += len(sel)
        sched.step()
        net.eval()
        with torch.no_grad():
            pv = net(Xt[va], Ft[va]).argmax(1).numpy()
        vacc = float((pv == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
        if (ep + 1) % 5 == 0:
            print(f"  ep{ep+1:3d} train {corr/tot:.4f} val {vacc:.4f}", flush=True)
    net.load_state_dict(best_state); net.eval()

    with torch.no_grad():
        logit = sum(torch.log_softmax(net(torch.roll(Xt, s, dims=2), Ft), 1)
                    for s in (0, -60, 60)) / 3.0
        pred = logit.argmax(1).numpy()
        emb = net(Xt, Ft, feat=True).numpy()

    wacc = float((pred[te] == y[te]).mean())
    votes = {}
    for i in np.flatnonzero(te):
        votes.setdefault(rec[i], []).append(pred[i])
    rcorrect = sum(int(np.bincount(v).argmax() == y[np.flatnonzero(rec == r)[0]])
                   for r, v in votes.items())
    racc = rcorrect / len(votes)
    print(f"window test acc {wacc:.4f}   record test acc {racc:.4f} ({rcorrect}/{len(votes)})")

    cm = np.zeros((7, 7), int)
    for r, v in votes.items():
        cm[y[np.flatnonzero(rec == r)[0]], np.bincount(v, minlength=7).argmax()] += 1

    # record-level embedding for the t-SNE
    recs = sorted(set(rec))
    E = np.stack([emb[rec == r].mean(0) for r in recs])
    Ry = np.array([y[np.flatnonzero(rec == r)[0]] for r in recs])
    Rte = np.array([bool(te[rec == r][0]) for r in recs])
    Y = tsne(E, perplexity=20, iters=1000)

    np.savez("a1_deep_tsne.npz", Y=Y, y=Ry, is_test=Rte, E=E, cm=cm, wacc=wacc, racc=racc)
    json.dump({"window_test_acc": wacc, "record_test_acc": racc,
               "n_train": int(tr.sum()), "n_test": int(te.sum()),
               "n_test_records": int(len(votes)), "cm": cm.tolist()},
              open("a1_deep_metrics.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
