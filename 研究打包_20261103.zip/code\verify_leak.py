"""Verification: is the 100 % coming from severity, or from the recording fingerprint?

1. check that train / test windows do not overlap in time
2. train on 60 Hz / 0.07 N.m, then test on the OTHER load recordings (same severities)
   -> if accuracy collapses, the model learned the recording, not the severity
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

LABELS = [1, 2, 3, 4, 6, 7, 9]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 32, 11, 2, 5), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 9, 2, 4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 7, 2, 3), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.feat = nn.Linear(128, 96)
        self.fc = nn.Linear(96, n_cls)

    def forward(self, x):
        return self.fc(self.feat(self.body(x).flatten(1)))


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]

    # ---- 1. overlap check on 60 Hz / 0.07 N.m (windows are 1500 samples at 10 kHz = 1000 raw-steps of 50 k)
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    print("windows at 60 Hz / 0.07:", m.sum(),
          "train/val/test =", (sp[m] == "train").sum(), (sp[m] == "val").sum(), (sp[m] == "test").sum())
    print("split column has guard bands baked in (one full window); windows inside a split overlap 67 %")

    # ---- 2. train on 0.07, test on other loads
    mt = m & (sp == "train")
    mv = m & (sp == "val")
    mte = m & (sp == "test")
    mu = x[mt].mean(axis=(0, 2), keepdims=True)
    sd = x[mt].std(axis=(0, 2), keepdims=True) + 1e-6
    norm = lambda a: ((a - mu) / sd).astype(np.float32)

    y = np.array([LABELS.index(int(v)) for v in y0])
    X, Y = torch.from_numpy(norm(x[mt])), torch.from_numpy(y[mt])
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    epochs = 120
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.arange(len(X))
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx)
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(X[s], int(torch.randint(-100, 101, (1,))), dims=2)
            loss = F.cross_entropy(net(xb), Y[s], label_smoothing=0.03)
            opt.zero_grad(); loss.backward(); opt.step()
        sched.step(); net.eval()
        with torch.no_grad():
            pv = net(torch.from_numpy(norm(x[mv]))).argmax(1).numpy()
        vacc = float((pv == y[mv]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()

    def acc(mask, tag):
        with torch.no_grad():
            p = net(torch.from_numpy(norm(x[mask]))).argmax(1).numpy()
        print(f"  {tag:38s} n={mask.sum():4d}  acc {(p == y[mask]).mean():.3f}")

    print("\nsame recording / same condition:")
    acc(mte, "0.07 N.m test split (unseen time)")
    print("\nother recordings / same severity, different load:")
    for L in (6.83, 20.49, 34.14):
        acc(np.isclose(speed, 60.0) & np.isclose(load, L), f"60 Hz / {L} N.m (unseen recording)")

    # ---- 3. does the model also separate the four loads perfectly? (recording fingerprint test)
    m60 = np.isclose(speed, 60.0)
    dom = np.array([int(np.argmin(np.abs(np.array([0.07, 6.83, 20.49, 34.14]) - l))) for l in load[m60]])
    with torch.no_grad():
        f = net.feat(net.body(torch.from_numpy(norm(x[m60]))).flatten(1)).numpy()
    # nearest-centroid load classification on the same features
    cent = np.stack([f[dom == k].mean(0) for k in range(4)])
    d2 = ((f[:, None, :] - cent[None]) ** 2).sum(-1)
    print(f"\nload can be decoded from the same features: "
          f"{(d2.argmin(1) == dom).mean():.3f} (4-class nearest centroid)")


if __name__ == "__main__":
    main()
