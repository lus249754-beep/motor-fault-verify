"""Single condition 60 Hz / 0.07 N.m, reasoning-style model.

Input : 27 dimensionless physical features (negative/zero sequence, phase amplitude
        ratios, harmonic ratios 2/3/5/7/9/11, THD). No raw waveform, so the network
        cannot memorise sensor offsets or the recording fingerprint.
Model : 27 -> 64 -> 64 -> 7, CE. Small capacity by design.
Checks: amplitude scaling / time shift / added noise must not change the decision,
        because every feature is a ratio.
"""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from deep_feat import physics_features
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]
torch.manual_seed(0)
np.random.seed(0)


class Net(nn.Module):
    def __init__(self, nf=27, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 64), nn.BatchNorm1d(64), nn.ReLU(), nn.Dropout(0.3),
                                  nn.Linear(64, 64), nn.BatchNorm1d(64), nn.ReLU())
        self.fc = nn.Linear(64, n_cls)

    def forward(self, x, feat=False):
        z = self.body(x)
        return z if feat else self.fc(z)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    Fp = physics_features(x, speed[m])
    Z = ((Fp - Fp[tr].mean(0)) / (Fp[tr].std(0) + 1e-6)).astype(np.float32)

    # interpretability: negative-sequence ratio per class
    i2 = Fp[:, 0]
    print("I2/I1 by class:", {SEV_TXT[c]: round(float(i2[y == c].mean()), 4) for c in range(7)})

    X, Y = torch.from_numpy(Z), torch.from_numpy(y)
    net = Net()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
    idx = np.flatnonzero(tr)
    for ep in range(250):
        net.train(); np.random.shuffle(idx)
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            loss = F.cross_entropy(net(X[s] + 0.05 * torch.randn_like(X[s])), Y[s])
            opt.zero_grad(); loss.backward(); opt.step()
    net.eval()
    with torch.no_grad():
        pred = net(X).argmax(1).numpy()
        emb = net(X, feat=True).numpy()
    acc = float((pred[te] == y[te]).mean())
    print(f"clean test acc {acc:.3f}")

    # invariance checks: perturb the raw waveform, recompute the physical features
    rng = np.random.RandomState(1)
    variants = {
        "amplitude x1.3": x * 1.3,
        "time shift 500": np.roll(x, 500, axis=2),
        "noise 2 %": x + 0.02 * rng.randn(*x.shape).astype(np.float32) * x.std(axis=(0, 2), keepdims=True),
    }
    for name, xv in variants.items():
        Fv = physics_features(xv.astype(np.float32), speed[m])
        Zv = ((Fv - Fp[tr].mean(0)) / (Fp[tr].std(0) + 1e-6)).astype(np.float32)
        with torch.no_grad():
            pv = net(torch.from_numpy(Zv)).argmax(1).numpy()
        print(f"  {name:16s} test acc {(pv[te] == y[te]).mean():.3f}")

    cm = np.zeros((7, 7), int)
    for t, p in zip(y[te], pred[te]):
        cm[t, p] += 1

    Yt = tsne(Z[te], perplexity=12, iters=1200)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5.4), gridspec_kw={"width_ratios": [1.35, 1]})
    for k in range(7):
        a1.scatter(Yt[y[te] == k, 0], Yt[y[te] == k, 1], s=46, c=COLORS[k], alpha=0.9,
                   linewidths=0, label=SEV_TXT[k] + " %")
    a1.set_xticks([]); a1.set_yticks([])
    a1.legend(fontsize=8, title="严重程度", title_fontsize=9)
    a1.set_title(f"物理特征空间 t-SNE（60 Hz / 0.07 N·m，测试切片 n={int(te.sum())}）", fontsize=10.5)
    a2.imshow(cm / np.maximum(cm.sum(1, keepdims=True), 1), cmap="Blues", vmin=0, vmax=1)
    for i in range(7):
        for j in range(7):
            if cm[i, j]:
                a2.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=9,
                        color="white" if cm[i, j] / max(cm[i].sum(), 1) > 0.5 else "#222")
    a2.set_xticks(range(7)); a2.set_yticks(range(7))
    a2.set_xticklabels(SEV_TXT, rotation=45, ha="right", fontsize=8)
    a2.set_yticklabels(SEV_TXT, fontsize=8)
    a2.set_xlabel("预测（%）"); a2.set_ylabel("真实（%）")
    a2.set_title(f"混淆矩阵（准确率 {acc*100:.1f}%）", fontsize=10.5)
    fig.suptitle("单一工况 60 Hz / 0.07 N·m：基于物理量的推理模型", fontsize=12.5, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.94))
    fig.savefig("figs/a1_reason_single.png", dpi=190)
    json.dump({"acc": acc, "n_test": int(te.sum())}, open("a1_reason_single.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
