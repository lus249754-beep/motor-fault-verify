"""Ceiling probe: physics features + per-condition normalisation, record-level test."""
import numpy as np
import torch

d = np.load("a1_7cls_10k.npz", allow_pickle=True)
x, y0, rec, speed, load = d["X"], d["y"], d["record"], d["speed"], d["load"]
LABELS = [1, 2, 3, 4, 6, 7, 9]
y = np.array([LABELS.index(int(v)) for v in y0])

N = x.shape[2]
FS = 10000.0
w = np.hanning(N).astype(np.float32)
spec = np.fft.rfft(x * w, axis=2)
a = np.exp(2j * np.pi / 3)


def feats(i):
    k1 = max(1, int(round(speed[i] / (FS / N))))
    ph = spec[i, :, k1]
    amp = np.abs(ph)
    m = amp.mean() + 1e-9
    I1 = (ph[0] + a * ph[1] + a * a * ph[2]) / 3
    I2 = (ph[0] + a * a * ph[1] + a * ph[2]) / 3
    I0 = ph.sum() / 3
    f = [abs(I2) / (abs(I1) + 1e-9), abs(I0) / (abs(I1) + 1e-9), abs(I1) / m]
    f += list(amp / m)
    for h in (2, 3, 5, 7, 9, 11):
        f += list(np.abs(spec[i, :, h * k1]) / (amp + 1e-9))
    for c in range(3):
        band = np.abs(spec[i, c, k1 + 1:])
        f.append(float(np.sqrt((band ** 2).sum()) / (amp[c] + 1e-9)))
    return np.array(f, dtype=np.float32)


F = np.stack([feats(i) for i in range(len(y))])
print("features", F.shape)

conds = np.array([(round(float(s), 2), round(float(l), 2)) for s, l in zip(speed, load)])

rng = np.random.RandomState(0)
te_rec = set()
for c in range(7):
    recs = sorted({r for r in rec[y == c]})
    rng.shuffle(recs)
    te_rec.update(recs[:2])
te = np.array([r in te_rec for r in rec])
tr = ~te
print("records train/test", len(set(rec[tr])), len(set(rec[te])), "windows", tr.sum(), te.sum())

# per-condition z-score using training windows only
Z = F.copy()
for key in set(map(tuple, conds)):
    m = np.all(conds == key, axis=1)
    mu, sd = F[m & tr].mean(0), F[m & tr].std(0) + 1e-6
    Z[m] = (F[m] - mu) / sd


def fit_eval(X, y, tr, te, hidden=128, epochs=400):
    net = torch.nn.Sequential(torch.nn.Linear(X.shape[1], hidden), torch.nn.ReLU(),
                              torch.nn.Dropout(0.3),
                              torch.nn.Linear(hidden, hidden), torch.nn.ReLU(),
                              torch.nn.Linear(hidden, 7))
    opt = torch.optim.Adam(net.parameters(), lr=3e-3, weight_decay=1e-3)
    Xt, yt = torch.from_numpy(X.astype(np.float32)), torch.from_numpy(y)
    for _ in range(epochs):
        net.train()
        opt.zero_grad()
        torch.nn.functional.cross_entropy(net(Xt[tr]), yt[tr]).backward()
        opt.step()
    net.eval()
    with torch.no_grad():
        prob = torch.softmax(net(Xt), 1).numpy()
    return prob


prob = fit_eval(Z, y, tr, te)
pred = prob.argmax(1)
print("window-level test acc %.3f" % (pred[te] == y[te]).mean())

# majority vote per held-out record
votes = {}
for i in np.flatnonzero(te):
    votes.setdefault(rec[i], []).append(prob[i])
ok = 0
for r, ps in votes.items():
    p = np.mean(ps, 0).argmax()
    t = y[np.flatnonzero(rec == r)[0]]
    ok += int(p == t)
print("record-level test acc %.3f (%d/%d)" % (ok / len(votes), ok, len(votes)))

# features without condition normalisation, same model
prob2 = fit_eval(F, y, tr, te)
pred2 = prob2.argmax(1)
votes2 = {}
for i in np.flatnonzero(te):
    votes2.setdefault(rec[i], []).append(prob2[i])
ok2 = sum(int(np.mean(ps, 0).argmax() == y[np.flatnonzero(rec == r)[0]]) for r, ps in votes2.items())
print("raw features: window %.3f record %.3f" % ((pred2[te] == y[te]).mean(), ok2 / len(votes2)))
