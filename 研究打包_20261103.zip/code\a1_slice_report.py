"""Summarise a slice run: summary.csv, label_map.csv, README.txt."""
import csv
import os
import sys
from collections import Counter, defaultdict

LEVELS = [1.98, 3.97, 5.95, 8.33, 12.30, 20.64, 28.97, 37.30, 45.63]


def main(out_dir, window=150000, stride=50000):
    rows = list(csv.DictReader(open(os.path.join(out_dir, "slice_index.csv"), encoding="utf-8-sig")))
    per_record = defaultdict(Counter)
    rec_meta = {}
    for r in rows:
        key = r["record"]
        per_record[key][r["split"]] += 1
        rec_meta[key] = r

    with open(os.path.join(out_dir, "summary.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Record", "Label", "SeverityPct", "SpeedHz", "LoadNm", "ResistanceOhm",
                    "Train", "Validation", "Test", "Total", "File"])
        for rec in sorted(per_record, key=lambda k: (float(rec_meta[k]["speed"]),
                                                     float(rec_meta[k]["load"]),
                                                     int(rec_meta[k]["label"]))):
            c = per_record[rec]
            m = rec_meta[rec]
            w.writerow([rec, m["label"], m["severity"], m["speed"], m["load"], m["resistance"],
                        c["train"], c["val"], c["test"], sum(c.values()),
                        m["file"]])

    with open(os.path.join(out_dir, "label_map.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Label", "SeverityPct"])
        for i, v in enumerate(LEVELS, 1):
            w.writerow([i, v])

    by_split = Counter(r["split"] for r in rows)
    by_label = Counter(int(r["label"]) for r in rows)
    by_speed = Counter(float(r["speed"]) for r in rows)
    n_rec = len(per_record)
    win_s = window / 1e6
    total = len(rows)
    text = f"""A1 slice dataset
================
Source      : E:\\A1  ({n_rec} records, each 5 005 000 points)
Channels    : CH02 / CH04 / CH06 (three-phase currents, float32, source units)
Sampling    : 1 MHz (assumed). A1 MAT files carry no WaveInfo block, so this is
              the acquisition setting, NOT independently verified here.
Window      : {window} points = {win_s:.3f} s  ({win_s*20:.1f} cycles at 20 Hz, {win_s*60:.1f} at 60 Hz)
Stride      : {stride} points = {stride/1e6:.3f} s  ({100*(1-stride/window):.0f}% overlap)
Split       : chronological 60/20/20 within each record, one full window
              ({window} points) removed between blocks so no slice straddles a split.
Dropped     : windows that fall in those guard bands are not saved.

Counts
------
slices total : {total}
per record   : {total/n_rec:.1f} (identical for every record)
train/val/test: {by_split['train']} / {by_split['val']} / {by_split['test']}
per label    : 1..9 -> {[by_label[i] for i in range(1, 10)]}
per speed    : {dict(sorted(by_speed.items()))}

Files
-----
<record>-slices.mat    one per source record, X (window, 3, nWin) float32
                       plus Y, sourceStart, sourceEnd, split, speed/load/resistance/severity
slice_index.csv        one row per saved slice (10 columns)
summary.csv            one row per record with split counts
label_map.csv          label -> severity

Caveats
-------
1. Overlapping slices are NOT independent samples. Split by record / condition
   before training; the chronological split here only prevents time leakage.
2. Each class still has 12 source records (3 speeds x 4 loads); a record-level
   or condition-level split is the honest way to measure generalisation.
3. No filtering, resampling or normalisation was applied.
4. Cross-resistance test (Rf=0.01 / 10 ohm) needs the same protocol applied to
   A0.01 and A10 for a like-for-like comparison.
"""
    open(os.path.join(out_dir, "README.txt"), "w", encoding="utf-8").write(text)
    print(f"{n_rec} records, {total} slices, splits {dict(by_split)}, sizes ok")
    print(text)


if __name__ == "__main__":
    main(sys.argv[1], *(int(a) for a in sys.argv[2:]) if len(sys.argv) > 2 else ())
