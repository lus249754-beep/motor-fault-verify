"""Dedicated severity regressor (no contrastive loss) -> cleaner 'between-levels' detection."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from deep_feat import physics_features
from reason_harm import extra_features
from accuracy_push import smooth
from openset_final import unseen_features, LABELS, SEV

np.random.seed(0)
torch.manual_seed(0)


class Reg(nn.Module):
    def __init__(self, nf):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 128), nn.BatchNorm1d(128), nn.ReLU(), nn.Dropout(0.2),
                                  nn.Linear(128, 128), nn.BatchNorm1d(128), nn.ReLU())
        self.out = nn.Linear(128, 1)

    def forward(self, x):
        return self.out(self.body(x)).squeeze(1)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    Fs = smooth(np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1), y)
    Fu_raw = unseen_features()
    Fu = smooth(Fu_raw, np.zeros(len(Fu_raw), int))
    mu, sd = Fs[tr].mean(0), Fs[tr].std(0) + 1e-6
    Z = torch.from_numpy(((Fs - mu) / sd).astype(np.float32))
    Zu = torch.from_numpy(((Fu - mu) / sd).astype(np.float32))
    tgt = torch.from_numpy(np.log(SEV)[y].astype(np.float32))

    preds_k, preds_u = [], []
    for seed in range(8):
        torch.manual_seed(seed); np.random.seed(seed)
        net = Reg(Z.shape[1])
        opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
        idx = np.flatnonzero(tr)
        for ep in range(400):
            net.train(); np.random.shuffle(idx)
            for b in range(0, len(idx), 64):
                s = idx[b:b + 64]
                loss = F.mse_loss(net(Z[s] + 0.03 * torch.randn_like(Z[s])), tgt[s])
                opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            preds_k.append(np.exp(net(Z).numpy()))
            preds_u.append(np.exp(net(Zu).numpy()))
    rk = np.mean(preds_k, 0)
    ru = np.mean(preds_u, 0)

    gap = lambda r: np.min(np.abs(r[:, None] - SEV[None]), 1)
    gk, gu = gap(rk), gap(ru)
    mae = float(np.mean(np.abs(rk[te] - SEV[y[te]])))
    print(f"known MAE {mae:.2f} pp | unseen pred: median {np.median(ru):.2f} "
          f"p10 {np.percentile(ru,10):.2f} p90 {np.percentile(ru,90):.2f}", flush=True)
    print(f"gap known: median {np.median(gk[te]):.3f} p99 {np.percentile(gk[te],99):.3f} | "
          f"unseen: median {np.median(gu):.3f} p10 {np.percentile(gu,10):.3f}", flush=True)

    out = {}
    for keep in (0.99, 0.98, 0.95):
        thr = float(np.quantile(gk[va], keep))
        ka = float((gk[te] < thr).mean())
        ur = float((gu >= thr).mean())
        out[str(keep)] = dict(threshold=thr, known_accept=ka, unknown_reject=ur)
        print(f"keep {keep:.2f} -> thr {thr:.3f}  known accept {ka:.3f}  unseen reject {ur:.3f}",
              flush=True)
    json.dump({"mae": mae, "median_unseen": float(np.median(ru)), "grid": out},
              open("a1_regressor_openset.json", "w"), indent=1)
    np.savez("a1_reg_arrays.npz", rk=rk, ru=ru, y=y, te=te, va=va)


if __name__ == "__main__":
    main()
