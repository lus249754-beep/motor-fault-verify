"""t-SNE with exact KL and autograd (Adam on Y). Verified on synthetic blobs."""
import numpy as np
import torch


def p_matrix(X, perplexity=30.0):
    X = torch.tensor(np.asarray(X), dtype=torch.float64)
    n = X.shape[0]
    d2 = torch.cdist(X, X) ** 2
    target = float(np.log(perplexity))
    P = torch.zeros(n, n, dtype=torch.float64)
    for i in range(n):
        d = d2[i].clone()
        d[i] = 1e18
        beta = 1.0
        lo, hi = 1e-20, 1e20
        p = None
        for _ in range(80):
            p = torch.exp(-d * beta)
            p = p / p.sum().clamp_min(1e-12)
            ent = -(p * torch.log(p.clamp_min(1e-12))).sum()
            diff = float(ent - target)
            if diff > 0:
                lo = beta
                beta = (beta + hi) / 2 if hi < 1e19 else beta * 2
            else:
                hi = beta
                beta = (beta + lo) / 2
            if abs(diff) < 1e-7:
                break
        P[i] = p
    P = (P + P.t()) / 2
    return P / P.sum()


def tsne(X, perplexity=30.0, iters=1200, lr=1.5, seed=0):
    torch.manual_seed(seed)
    X = np.asarray(X, dtype=np.float64)
    X = (X - X.mean(0)) / (X.std(0) + 1e-9)
    P = p_matrix(X, perplexity)
    n = X.shape[0]
    Y = torch.randn(n, 2, dtype=torch.float64) * 0.01
    Y.requires_grad_(True)
    opt = torch.optim.Adam([Y], lr=lr)
    for it in range(iters):
        opt.zero_grad()
        num = 1.0 / (1.0 + torch.cdist(Y, Y) ** 2)
        num.fill_diagonal_(0)
        Q = num / num.sum()
        kl = (P * torch.log(P.clamp_min(1e-12) / Q.clamp_min(1e-12))).sum()
        exag = 4.0 if it < iters // 4 else 1.0
        (kl * exag).backward()
        opt.step()
        with torch.no_grad():
            Y -= Y.mean(0)
        if (it + 1) % 300 == 0:
            print(f"  tsne {it+1}/{iters} KL {float(kl):.3f}", flush=True)
    return Y.detach().numpy()


if __name__ == "__main__":
    rng = np.random.RandomState(0)
    X, y = [], []
    for k in range(7):
        c = rng.randn(10) * 4
        X.append(c + rng.randn(40, 10))
        y += [k] * 40
    X = np.vstack(X)
    y = np.array(y)
    Y = tsne(X, perplexity=10, iters=1200)
    d = np.linalg.norm(Y[:, None] - Y[None], axis=2)
    np.fill_diagonal(d, 1e9)
    print("nn purity %.3f" % (y[d.argmin(1)] == y).mean())
    for k in range(7):
        print(k, np.round(Y[y == k].mean(0), 1), np.round(Y[y == k].std(0), 1))
