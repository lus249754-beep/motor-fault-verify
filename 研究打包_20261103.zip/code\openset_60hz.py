"""Open-set test at 60 Hz: train on 7 severities, reject the two unseen severities.

Known : labels 1,2,3,4,6,7,9   (1.98 .. 45.63 %)
Unknown: labels 5 (12.30 %) and 8 (37.30 %) -- never shown to the model.
Scores : max-softmax (MSP) and Mahalanobis distance to class prototypes (feature space).
"""
import glob
import json
import os

import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.signal import resample

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 32, 11, 2, 5), nn.BatchNorm1d(32), nn.ReLU(),
            nn.Conv1d(32, 64, 9, 2, 4), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 7, 2, 3), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.feat = nn.Linear(128, 96)
        self.proj = nn.Sequential(nn.Linear(96, 64), nn.ReLU(), nn.Linear(64, 32))
        self.fc = nn.Linear(96, n_cls)

    def forward(self, x):
        h = self.body(x).flatten(1)
        f = self.feat(h)
        return f, self.proj(f), self.fc(f)


def supcon(z, y, t=0.1):
    z = F.normalize(z, 1)
    sim = z @ z.t() / t
    n = z.shape[0]
    eye = torch.eye(n, dtype=torch.bool)
    sim = sim.masked_fill(eye, -1e9)
    logp = sim - torch.logsumexp(sim, 1, keepdim=True)
    pos = (y[:, None] == y[None, :]) & ~eye
    logp = logp.masked_fill(~pos, 0.0)
    return -(logp.sum(1) / pos.sum(1).clamp_min(1)).mean()


def load_unknown(mean, std):
    """60 Hz windows of the two unseen severities, conditioned exactly like training data."""
    files = [f for f in sorted(glob.glob("a1_slices/*-slices.mat"))
             if os.path.basename(f).startswith("60-")
             and ("-A-12.30-slices" in f or "-A-37.30-slices" in f)]
    xs, ys = [], []
    for f in files:
        X = np.asarray(sio.loadmat(f)["X"], dtype=np.float32)      # (150000, 3, n)
        X = X[:, :, ::3]                                           # non-overlapping subset
        m3, s3 = mean.reshape(3, 1), std.reshape(3, 1)
        for k in range(X.shape[2]):
            y = resample(X[:, :, k], 1500, axis=0).T          # (3, 1500)
            xs.append(((y - m3) / s3).astype(np.float32))
        label = 5 if "12.30" in f else 8
        ys.append(np.full(X.shape[2], label, np.int64))
        print("  unknown", os.path.basename(f), X.shape[2], flush=True)
    return np.stack(xs), np.concatenate(ys)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, rec, speed = d["X"], d["y"], d["record"], d["speed"]
    m = np.isclose(speed, 60.0)
    x, rec = x[m], rec[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    keep = np.zeros(len(y), bool)
    for r in set(rec):
        idx = np.flatnonzero(rec == r)
        keep[idx[::3]] = True
    x, y = x[keep], y[keep]

    rng = np.random.RandomState(0)
    tr = np.zeros(len(y), bool); va = np.zeros(len(y), bool); te = np.zeros(len(y), bool)
    for c in range(7):
        idx = np.flatnonzero(y == c)
        rng.shuffle(idx)
        n = len(idx)
        te[idx[:int(0.15 * n)]] = True
        va[idx[int(0.15 * n):int(0.30 * n)]] = True
        tr[idx[int(0.30 * n):]] = True
    print("known slices train/val/test", tr.sum(), va.sum(), te.sum(), flush=True)

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)
    xu, yu = load_unknown(mu, sd)
    print("unknown slices", xu.shape, flush=True)

    X, Y = torch.from_numpy(x), torch.from_numpy(y)
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=1e-3)
    epochs = 120
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), 64):
            s = idx[b:b + 64]
            xb = torch.roll(X[s], int(torch.randint(-100, 101, (1,))), dims=2)
            f, z, out = net(xb)
            loss = F.cross_entropy(out, Y[s], label_smoothing=0.03) + 0.5 * supcon(z, Y[s])
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == Y[s]).sum().item(); tot += len(s)
        sched.step(); net.eval()
        with torch.no_grad():
            vacc = float((net(X[va])[2].argmax(1).numpy() == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state); net.eval()

    def embed(a):
        with torch.no_grad():
            t = torch.from_numpy(a)
            f, _, logit = net(t)
        return f.numpy(), logit.numpy()

    ftr, _ = embed(x[tr])
    fva, lva = embed(x[va])
    fte, lte = embed(x[te])
    fuk, luk = embed(xu)

    # class prototypes and shared covariance in the feature space
    proto = np.stack([ftr[y[tr] == c].mean(0) for c in range(7)])
    r = ftr - proto[y[tr]]
    cov = np.cov(r.T) + 1e-3 * np.eye(ftr.shape[1])
    icov = np.linalg.inv(cov)

    def mahal(f):
        d = np.zeros((len(f), 7))
        for c in range(7):
            df = f - proto[c]
            d[:, c] = np.einsum("ij,jk,ik->i", df, icov, df)
        return d.min(1)

    def msp(logit):
        p = torch.softmax(torch.from_numpy(logit), 1).numpy()
        return p.max(1)

    scores = {
        "msp": (msp(lva), msp(lte), msp(luk), -1),          # higher = more known
        "mahalanobis": (-mahal(fva), -mahal(fte), -mahal(fuk), +1),
    }
    out = {}
    for name, (sva, ste, suk, sign) in scores.items():
        # threshold keeps 99% of the validation (known) slices accepted
        thr = np.quantile(sva, 0.01) if sign == 1 else np.quantile(sva, 0.99)
        known_accept = float((ste >= thr).mean())
        unknown_reject = float((suk < thr).mean())
        # AUROC known vs unknown
        s = np.concatenate([ste, suk])
        lab = np.concatenate([np.ones(len(ste)), np.zeros(len(suk))])
        order = np.argsort(-s)
        lab = lab[order]
        tpr = np.cumsum(lab) / lab.sum()
        fpr = np.cumsum(1 - lab) / (1 - lab).sum()
        auroc = float(np.trapezoid(tpr, fpr))
        pred = lte.argmax(1)
        acc_known_all = float((pred == y[te]).mean())
        acc_known_acc = float((pred[ste >= thr] == y[te][ste >= thr]).mean()) if (ste >= thr).any() else 0.0
        out[name] = dict(threshold=float(thr), known_accept=known_accept,
                         unknown_reject=unknown_reject, auroc=auroc,
                         acc_known_all=acc_known_all, acc_known_accepted=acc_known_acc,
                         unknown_by_class={int(k): float((suk[yu == k] < thr).mean())
                                           for k in (5, 8)})
        print(name, json.dumps(out[name], indent=1), flush=True)
    json.dump(out, open("a1_openset_60hz.json", "w"), indent=1)
    np.savez("a1_openset_60hz.npz", fva=fva, fte=fte, fuk=fuk, yte=y[te], yu=yu,
             lva=lva, lte=lte, luk=luk, sva={k: v[0] for k, v in scores.items()},
             ste={k: v[1] for k, v in scores.items()}, suk={k: v[2] for k, v in scores.items()})
    print("saved")


if __name__ == "__main__":
    main()
