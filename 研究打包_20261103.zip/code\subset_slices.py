"""Select a subset of severity labels from an existing slice dataset.

    python subset_slices.py --src a1_slices --out a1_slices_6cls --labels 1,2,4,6,7,9
"""
import argparse
import csv
import os
import shutil

import numpy as np
import scipy.io as sio

FIELDS = ("X", "Y", "sourceStart", "sourceEnd", "split", "fs", "windowLength", "step",
          "channelNames", "sourceFile", "speed", "load", "resistance", "severity", "label",
          "samplingRateVerified", "samplingRateSource")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--labels", required=True)
    ap.add_argument("--renumber", action="store_true")
    args = ap.parse_args()

    keep = sorted({int(x) for x in args.labels.split(",")})
    os.makedirs(args.out, exist_ok=True)
    rows = list(csv.DictReader(open(os.path.join(args.src, "slice_index.csv"), encoding="utf-8-sig")))
    by_file = {}
    for r in rows:
        by_file.setdefault(r["file"], []).append(r)

    new_rows, n_rec = [], 0
    for fname, rs in sorted(by_file.items()):
        labels = {int(r["label"]) for r in rs}
        if not labels & set(keep):
            continue
        d = sio.loadmat(os.path.join(args.src, fname))
        y = np.asarray(d["Y"]).ravel().astype(int)
        m = np.isin(y, keep)
        if not m.any():
            continue
        out = {}
        for k in FIELDS:
            if k not in d:
                continue
            v = d[k]
            if k == "X":
                out[k] = np.asarray(v)[:, :, m].astype(np.float32)
            elif k in ("Y", "sourceStart", "sourceEnd", "split"):
                vv = np.asarray(v)
                out[k] = vv[m] if vv.ndim and vv.shape[0] == m.size else vv
        if args.renumber:
            mapping = {old: i + 1 for i, old in enumerate(keep)}
            out["Y"] = np.vectorize(mapping.get)(np.asarray(out["Y"]).ravel()).astype(np.uint8)
            out["label"] = np.uint8(mapping[int(np.asarray(d["label"]).ravel()[0])])
        sio.savemat(os.path.join(args.out, fname), out, do_compression=True, oned_as="column")
        n_rec += 1
        for r in rs:
            if int(r["label"]) in keep:
                new_rows.append(r)
        print(f"{fname:34s} keep {int(m.sum()):3d}/{m.size}  {os.path.getsize(os.path.join(args.out, fname))/1e6:6.1f} MB", flush=True)

    with open(os.path.join(args.out, "slice_index.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(new_rows)
    for extra in ("label_map.csv", "README.txt"):
        p = os.path.join(args.src, extra)
        if os.path.exists(p):
            shutil.copy2(p, os.path.join(args.out, extra))
    print(f"records {n_rec}, slices {len(new_rows)}")
    with open(os.path.join(args.out, "subset.txt"), "w", encoding="utf-8") as f:
        f.write(f"source dir : {args.src}\nkept labels: {keep}\nrecords    : {n_rec}\n"
                f"slices     : {len(new_rows)}\nrenumbered : {args.renumber}\n")


if __name__ == "__main__":
    main()
