"""20 Hz only, simplest CNN, held-out time segments (train 60 / val / test 20)."""
import json

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from tsne_adam import tsne

LABELS = [1, 2, 3, 4, 6, 7, 9]
torch.manual_seed(0)
np.random.seed(0)


class CNN(nn.Module):
    def __init__(self, n_cls=7):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv1d(3, 24, 9, 2, 4), nn.BatchNorm1d(24), nn.ReLU(),
            nn.Conv1d(24, 48, 7, 2, 3), nn.BatchNorm1d(48), nn.ReLU(),
            nn.Conv1d(48, 96, 5, 2, 2), nn.BatchNorm1d(96), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1))
        self.fc = nn.Linear(96, n_cls)

    def forward(self, x, feat=False):
        z = self.body(x).flatten(1)
        return z if feat else self.fc(z)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp = d["X"], d["y"], d["split"]
    speed = d["speed"]
    m = np.isclose(speed, 20.0)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"
    print("windows", tr.sum(), va.sum(), te.sum(), flush=True)

    mu = x[tr].mean(axis=(0, 2), keepdims=True)
    sd = x[tr].std(axis=(0, 2), keepdims=True) + 1e-6
    x = ((x - mu) / sd).astype(np.float32)

    X, Y = torch.from_numpy(x), torch.from_numpy(y)
    net = CNN()
    opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=5e-4)
    epochs = 100
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    idx = np.flatnonzero(tr)
    best, best_state = -1, None
    for ep in range(epochs):
        net.train(); np.random.shuffle(idx); corr = tot = 0
        for b in range(0, len(idx), 128):
            s = idx[b:b + 128]
            xb = torch.roll(X[s], int(torch.randint(-200, 201, (1,))), dims=2)
            xb = xb + 0.02 * torch.randn_like(xb)
            out = net(xb)
            loss = F.cross_entropy(out, Y[s], label_smoothing=0.03)
            opt.zero_grad(); loss.backward(); opt.step()
            corr += (out.argmax(1) == Y[s]).sum().item(); tot += len(s)
        sched.step(); net.eval()
        with torch.no_grad():
            pv = net(X[va]).argmax(1).numpy()
        vacc = float((pv == y[va]).mean())
        if vacc > best:
            best, best_state = vacc, {k: v.clone() for k, v in net.state_dict().items()}
        if (ep + 1) % 20 == 0:
            print(f"  ep{ep+1:3d} train {corr/tot:.4f} val {vacc:.4f}", flush=True)
    net.load_state_dict(best_state); net.eval()
    with torch.no_grad():
        logit = sum(torch.log_softmax(net(torch.roll(X, s, dims=2)), 1)
                    for s in (0, -60, 60)) / 3
        pred = logit.argmax(1).numpy()
        emb = net(X, feat=True).numpy()
    acc = float((pred[te] == y[te]).mean())
    print("test acc %.4f" % acc)

    cm = np.zeros((7, 7), int)
    for t, p in zip(y[te], pred[te]):
        cm[t, p] += 1

    Y2 = tsne(emb[te], perplexity=30, iters=1200)
    np.savez("a1_20hz_time_tsne.npz", Y=Y2, y=y[te], cm=cm, acc=acc)
    json.dump({"acc": acc, "n_train": int(tr.sum()), "n_test": int(te.sum())},
              open("a1_20hz_time_metrics.json", "w"), indent=1)
    print("saved")


if __name__ == "__main__":
    main()
