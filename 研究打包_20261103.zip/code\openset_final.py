"""Final open-set pipeline at 60 Hz / 0.07 N.m (7 known classes + unseen 12.30 %)."""
import json

import numpy as np
import scipy.io as sio
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import resample

from deep_feat import physics_features
from reason_harm import extra_features, supcon
from accuracy_push import smooth
from tsne_adam import tsne

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei"]
plt.rcParams["axes.unicode_minus"] = False

LABELS = [1, 2, 3, 4, 6, 7, 9]
SEV = np.array([1.98, 3.97, 5.95, 8.33, 20.64, 28.97, 45.63])
SEV_TXT = ["1.98", "3.97", "5.95", "8.33", "20.64", "28.97", "45.63"]
COLORS = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#DA8BC3"]
GAP = (3, 4)
NSEED = 5


class Net(nn.Module):
    def __init__(self, nf):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(nf, 64), nn.BatchNorm1d(64), nn.ReLU(),
                                  nn.Linear(64, 64), nn.BatchNorm1d(64), nn.ReLU())
        self.proj = nn.Sequential(nn.Linear(64, 32), nn.ReLU(), nn.Linear(32, 16))
        self.fc = nn.Linear(64, 7)
        self.reg = nn.Linear(64, 1)

    def forward(self, x):
        z = self.body(x)
        return z, self.proj(z), self.fc(z), self.reg(z).squeeze(1)


def unseen_features():
    Xr = np.asarray(sio.loadmat("a1_slices/60-0.07-1-A-12.30-slices.mat")["X"], dtype=np.float32)
    w = np.stack([resample(Xr[:, :, k], 1500, axis=0).T for k in range(Xr.shape[2])]).astype(np.float32)
    s = np.full(len(w), 60.0)
    return np.concatenate([physics_features(w, s), extra_features(w, s)], 1)


def main():
    d = np.load("a1_7cls_10k.npz", allow_pickle=True)
    x, y0, sp, speed, load = d["X"], d["y"], d["split"], d["speed"], d["load"]
    m = np.isclose(speed, 60.0) & np.isclose(load, 0.07)
    x, sp = x[m], sp[m]
    y = np.array([LABELS.index(int(v)) for v in y0[m]])
    tr, va, te = sp == "train", sp == "val", sp == "test"

    Fs = smooth(np.concatenate([physics_features(x, speed[m]), extra_features(x, speed[m])], 1), y)
    Fu_raw = unseen_features()
    Fu = smooth(Fu_raw, np.zeros(len(Fu_raw), int))
    mu, sd = Fs[tr].mean(0), Fs[tr].std(0) + 1e-6
    Z = torch.from_numpy(((Fs - mu) / sd).astype(np.float32))
    Zu = torch.from_numpy(((Fu - mu) / sd).astype(np.float32))
    Y = torch.from_numpy(y)
    tgt = torch.from_numpy(np.log(SEV)[y].astype(np.float32))

    embs, embs_u, probs, reg_k, reg_u = [], [], [], [], []
    for seed in range(NSEED):
        torch.manual_seed(seed); np.random.seed(seed)
        net = Net(Fs.shape[1])
        opt = torch.optim.AdamW(net.parameters(), lr=2e-3, weight_decay=3e-3)
        idx = np.flatnonzero(tr)
        for ep in range(300):
            net.train(); np.random.shuffle(idx)
            for b in range(0, len(idx), 64):
                s = idx[b:b + 64]
                xb = Z[s] + 0.05 * torch.randn_like(Z[s])
                z, p, out, r = net(xb)
                loss = (F.cross_entropy(out, Y[s]) + 0.8 * supcon(p, Y[s])
                        + 0.5 * F.smooth_l1_loss(r, tgt[s]))
                opt.zero_grad(); loss.backward(); opt.step()
        net.eval()
        with torch.no_grad():
            embs.append(F.normalize(net(Z)[1], dim=1).numpy())
            embs_u.append(F.normalize(net(Zu)[1], dim=1).numpy())
            probs.append(F.softmax(net(Z)[2], 1).numpy())
            reg_k.append(np.exp(net(Z)[3].numpy()))
            reg_u.append(np.exp(net(Zu)[3].numpy()))
        print(f"seed {seed} done", flush=True)

    E = np.mean(embs, 0)
    Eu = np.mean(embs_u, 0)
    pred = np.mean(probs, 0).argmax(1)
    acc = float((pred[te] == y[te]).mean())
    rk = np.mean(reg_k, 0)
    ru = np.mean(reg_u, 0)

    # Mahalanobis on the embedding, prototypes from the train split
    proto = np.stack([E[tr & (y == c)].mean(0) for c in range(7)])
    icov = np.linalg.inv(np.cov((E[tr] - proto[y[tr]]).T) + 1e-3 * np.eye(E.shape[1]))

    def dist(F):
        return np.stack([np.einsum("ij,jk,ik->i", F - proto[c], icov, F - proto[c])
                         for c in range(7)]).min(0)

    dtr, dva, dte, du = dist(E[tr]), dist(E[va]), dist(E[te]), dist(Eu)
    thr = float(np.quantile(dva, 0.99))
    known_accept = float((dte < thr).mean())
    unknown_reject = float((du >= thr).mean())
    mae = float(np.mean(np.abs(rk[te] - SEV[y[te]])))
    in_band = float(((ru > SEV[GAP[0]]) & (ru < SEV[GAP[1]])).mean())

    print(f"acc {acc:.4f} | MAE {mae:.2f} | accept {known_accept:.3f} | reject {unknown_reject:.3f}"
          f" | in-band {in_band:.3f} | median {np.median(ru):.2f}", flush=True)
    json.dump({"acc": acc, "severity_mae": mae, "known_accept": known_accept,
               "unknown_reject": unknown_reject, "stage2_in_band": in_band,
               "stage2_median": float(np.median(ru)), "threshold": thr,
               "n_unseen": int(len(ru))}, open("a1_openset_final.json", "w"), indent=1)

    # ---------------- figure
    call = np.concatenate([E, Eu])
    Ys = tsne(call, perplexity=30, iters=2000)
    nk = len(E)
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.4, 5.8), gridspec_kw={"width_ratios": [1.4, 1]})
    for c in range(7):
        mm = y == c
        a1.scatter(Ys[:nk][mm, 0], Ys[:nk][mm, 1], s=24, c=COLORS[c], alpha=0.8,
                   linewidths=0, label=f"{SEV_TXT[c]} %")
    a1.scatter(Ys[nk:, 0], Ys[nk:, 1], s=22, marker="x", c="#B22222", linewidths=0.9,
               alpha=0.85, label="12.30 %（未训练）")
    a1.set_xticks([]); a1.set_yticks([])
    a1.legend(fontsize=8, ncol=2, title="严重度", title_fontsize=9, loc="best")
    a1.set_title(f"t-SNE 嵌入（已知 602 切片 + 未见 {len(Eu)} 切片）", fontsize=10.5)
    a2.hist(ru, bins=np.linspace(6, 24, 30), color="#C44E52", alpha=0.85)
    a2.axvspan(SEV[GAP[0]], SEV[GAP[1]], color="#4C72B0", alpha=0.15)
    a2.axvline(SEV[GAP[0]], color="#4C72B0", ls="--"); a2.axvline(SEV[GAP[1]], color="#4C72B0", ls="--")
    a2.set_xlabel("第二级回归预测的严重度（%）"); a2.set_ylabel("切片数")
    a2.set_title(f"未见 12.30 %：{in_band*100:.0f}% 落在 8.33–20.64 % → 第 5 档\n"
                 f"第一级拒绝率 {unknown_reject*100:.0f}%，已知测试接受率 {known_accept*100:.0f}%",
                 fontsize=10.5)
    fig.suptitle("60 Hz / 0.07 N·m：开集拒绝 + 严重度回归定位", fontsize=13, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    fig.savefig("figs/a1_openset_final.png", dpi=190)
    print("saved")


if __name__ == "__main__":
    main()
